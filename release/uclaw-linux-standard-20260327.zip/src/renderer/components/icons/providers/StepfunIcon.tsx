import React from 'react';

const StepfunIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" style={{flex: '0 0 auto', lineHeight: 1}}>
    <title>Stepfun</title>
    <path d="M23.2964 14.7395H17.4448V23.2981H12.9565V13.2307H23.2964V14.7395ZM20.355 8.24341H10.4683V20.1165H0.63916V15.76H5.94385L5.94678 3.90942H20.355V8.24341ZM4.02002 12.5881H2.48779V2.51685H4.02002V12.5881ZM22.4272 1.60962H23.3394V2.51587H22.4272V4.32544H21.519V2.51587H19.6997V1.60962H21.519V0.702393H22.4272V1.60962Z" fill="#005AFF" />
  </svg>
);

export default StepfunIcon;
