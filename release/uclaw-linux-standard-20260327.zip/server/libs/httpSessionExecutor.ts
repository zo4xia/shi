import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import type { SessionExecutor } from '../../clean-room/spine/modules/sessionOrchestrator';
import type {
  CoworkMessage,
  CoworkMessageMetadata,
  CoworkStore,
} from '../../src/main/coworkStore';
import { buildOpenAIChatCompletionsURL } from '../../src/main/libs/coworkFormatTransform';
import {
  pickNextApiKey,
  resolveAgentRolesFromConfig,
  resolveSupportedDesignerImageApiType,
  type AgentRoleKey,
} from '../../src/shared/agentRoleConfig';
import type { SqliteStore } from '../sqliteStore.web';
import { getProjectRoot, resolveRuntimeUserDataPath } from '../../src/shared/runtimeDataPaths';
import {
  BROWSER_EYES_CURRENT_PAGE_STORE_KEY,
  type BrowserEyesCurrentPageState,
} from '../../src/shared/browserEyesState';
import {
  buildNativeCapabilitySystemPrompts,
  createNativeCapabilitySdkTools,
  tryHandleNativeCapabilityDirectTurn,
} from '../../src/shared/nativeCapabilities';
import { readCurrentBrowserEyesStateFromConfigStore } from '../../src/shared/browserObserverRuntime';
import { z } from 'zod';
import { getRoleSkillsIndexPath } from './roleSkillFiles';
import { getRoleCapabilitySnapshotPath } from './roleRuntimeViews';
import {
  emitSessionComplete,
  emitSessionError,
  emitSessionMessage,
  emitSessionMessageUpdate,
  emitSessionsChanged,
} from './sessionEventSink';
import { resolveContinuityBootstrap } from './continuityBootstrap';
import { SessionTurnFinalizer } from './sessionTurnFinalizer';
import { parseFile } from './fileParser';
import {
  buildTurnCacheKey,
  getTurnCacheEntry,
  putTurnCacheEntry,
} from './turnCache';

type ImageAttachment = {
  name: string;
  mimeType: string;
  base64Data: string;
};

type GeneratedImage = {
  name: string;
  mimeType?: string;
  base64Data?: string;
  url?: string;
};

type AssistantOutput = {
  text: string;
  generatedImages: GeneratedImage[];
};

type SkillPromptBuilder = (skillIds: string[]) => string | null | Promise<string | null>;

type TurnOptions = {
  skipInitialUserMessage?: boolean;
  skillIds?: string[];
  systemPrompt?: string;
  autoApprove?: boolean;
  workspaceRoot?: string;
  confirmationMode?: 'modal' | 'text';
  imageAttachments?: ImageAttachment[];
};

type ActiveExecution = {
  abortController: AbortController;
};

type OpenAIMessage = {
  role: 'system' | 'user' | 'assistant';
  content: string | Array<{
    type: 'text';
    text: string;
  } | {
    type: 'image_url';
    image_url: {
      url: string;
    };
  }>;
};

type OpenAIToolCall = {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string;
  };
};

type OpenAIAssistantToolCallMessage = {
  role: 'assistant';
  content: OpenAIMessage['content'] | null;
  tool_calls: OpenAIToolCall[];
};

type OpenAIToolResultMessage = {
  role: 'tool';
  tool_call_id: string;
  content: string;
};

type OpenAIRequestMessage = OpenAIMessage | OpenAIAssistantToolCallMessage | OpenAIToolResultMessage;

type ExecutorToolDefinition = {
  name: string;
  spec: {
    type: 'function';
    function: {
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    };
  };
  handler: (args: any) => Promise<{ text: string; isError?: boolean }>;
};

const DEFAULT_OPENAI_MAX_TOKENS = 4096;
const CACHE_REPLAY_CHUNK_SIZE = 48;
const CACHE_REPLAY_CHUNK_DELAY_MS = 10;
const FORWARDED_RAW_CONTEXT_MESSAGE_LIMIT = 5;
const BOUNDED_LOOP_MAX_STEPS = 10;
const BOUNDED_LOOP_MAX_DURATION_MS = 90_000;
const ATTACHMENT_INPUT_LABEL = '输入文件';
const MAX_PARSED_ATTACHMENT_COUNT = 4;
const MAX_PARSED_ATTACHMENT_TOTAL_CHARS = 24000;
const MAX_PARSED_ATTACHMENT_BYTES = 20 * 1024 * 1024;
const BLINGBLING_LITTLE_EYE_SKILL_ID = 'blingbling-little-eye';
const BLINGBLING_OBSERVER_SCRIPT = path.join('scripts', 'observe-page.mjs');
const BLINGBLING_OBSERVER_TIMEOUT_MS = 12000;
const BLINGBLING_OBSERVER_PROMPT_MAX_CHARS = 5000;
const BLINGBLING_CURRENT_PAGE_MAX_AGE_MS = 15 * 60 * 1000;

type DirectApiConfig = {
  baseURL: string;
  apiKey: string;
  model: string;
  agentRoleKey: AgentRoleKey;
  imageApiType?: string;
};

export class HttpSessionExecutor implements SessionExecutor {
  private readonly activeSessions = new Map<string, ActiveExecution>();
  private readonly finalizer: SessionTurnFinalizer;

  constructor(
    private readonly store: CoworkStore,
    private readonly configStore: SqliteStore,
    private readonly buildSelectedSkillsPrompt: SkillPromptBuilder | null = null
  ) {
    this.finalizer = new SessionTurnFinalizer(store);
  }

  isSessionActive(sessionId: string): boolean {
    return this.activeSessions.has(sessionId);
  }

  stopSession(sessionId: string): boolean {
    const active = this.activeSessions.get(sessionId);
    if (!active) {
      return false;
    }

    active.abortController.abort();
    this.activeSessions.delete(sessionId);
    this.store.updateSession(sessionId, { status: 'idle' });
    emitSessionsChanged(sessionId, 'stopped');
    return true;
  }

  async startSession(sessionId: string, prompt: string, options: TurnOptions = {}): Promise<void> {
    await this.executeTurn(sessionId, prompt, options, 'start');
  }

  async continueSession(sessionId: string, prompt: string, options: TurnOptions = {}): Promise<void> {
    await this.executeTurn(sessionId, prompt, options, 'continue');
  }

  async runChannelFastTurn(sessionId: string, prompt: string, options: TurnOptions = {}): Promise<void> {
    await this.executeTurn(sessionId, prompt, options, 'channel');
  }

  private async executeTurn(
    sessionId: string,
    prompt: string,
    options: TurnOptions,
    mode: 'start' | 'continue' | 'channel'
  ): Promise<void> {
    // 【1.0链路】HTTP-EXEC-TURN: 当前稳定执行主链，负责状态切换、消息写入、直连 OpenAI 兼容流式请求。
    if (this.activeSessions.has(sessionId)) {
      throw new Error(`Session ${sessionId} is already running`);
    }

    const existingSession = this.store.getSession(sessionId);
    if (!existingSession) {
      throw new Error(`Session ${sessionId} not found`);
    }

    const abortController = new AbortController();
    const streamState = createStreamState();
    this.activeSessions.set(sessionId, { abortController });

    try {
      this.store.updateSession(sessionId, { status: 'running' });
      if (options.workspaceRoot?.trim()) {
        this.store.updateSession(sessionId, { cwd: path.resolve(options.workspaceRoot) });
      }
      emitSessionsChanged(sessionId, 'running');

      if (mode === 'channel' || !options.skipInitialUserMessage) {
        this.ensureLatestUserMessage(sessionId, prompt, options);
      }

      this.finalizer.prepareTurn(sessionId);

      const session = this.store.getSession(sessionId);
      if (!session) {
        throw new Error(`Session ${sessionId} disappeared during execution`);
      }

      const apiConfig = this.resolveDirectApiConfig(session.agentRoleKey);
      if (!apiConfig) {
        throw new Error('API configuration not found. Please configure model settings.');
      }

      const mergedSkillIds = this.resolveMergedSkillIds(session, options);
      const systemPrompt = await this.buildSystemPrompt(sessionId, session.systemPrompt || '', options, mode);
      const effectiveImageApiType = resolveSupportedDesignerImageApiType(apiConfig.imageApiType);
      if (apiConfig.agentRoleKey === 'designer' && effectiveImageApiType === 'google') {
        await this.runGoogleGenerateContent(sessionId, session, systemPrompt, apiConfig, streamState, abortController.signal);
      } else if (apiConfig.agentRoleKey === 'designer' && effectiveImageApiType === 'images') {
        await this.runOpenAIImagesGeneration(sessionId, session, systemPrompt, apiConfig, streamState, abortController.signal);
      } else if (this.needsBoundedToolLoop(session, prompt, mergedSkillIds)) {
        // {BREAKPOINT} DIRECT-EXECUTOR-BOUNDED-LOOP
        // {FLOW} PHASE1-DIRECT-IF-COMPAT: 主链默认仍走轻 single-shot；仅在明确需要工具回环时进入受控兼容层。
        // {标记} P0-BOUND-LOOP-COMPAT: 限制 10 步 / 90 秒，避免重链无限拖垮低配机与长会话。
        await this.runBoundedToolLoop(
          sessionId,
          session,
          prompt,
          systemPrompt,
          apiConfig,
          streamState,
          abortController.signal
        );
      } else {
        await this.runOpenAIStream(sessionId, session, systemPrompt, apiConfig, streamState, abortController.signal);
      }

      this.finishAssistantMessage(sessionId, streamState);
      this.store.updateSession(sessionId, { status: 'completed' });
      if (mode === 'channel') {
        this.finalizeChannelTurnInBackground(sessionId);
      } else {
        await this.finalizer.finalize(sessionId);
      }
      emitSessionComplete(sessionId, null);
      emitSessionsChanged(sessionId, 'completed');
    } catch (error) {
      if (abortController.signal.aborted) {
        this.store.updateSession(sessionId, { status: 'idle' });
        emitSessionsChanged(sessionId, 'aborted');
        return;
      }

      const message = error instanceof Error ? error.message : String(error);
      this.finishAssistantMessage(sessionId, streamState);
      this.store.updateSession(sessionId, { status: 'error' });
      const systemMessage = this.store.addMessage(sessionId, {
        type: 'system',
        content: `Error: ${message}`,
        metadata: { error: message },
      });
      emitSessionMessage(sessionId, systemMessage);
      if (mode === 'channel') {
        this.finalizeChannelTurnInBackground(sessionId);
      } else {
        await this.finalizer.finalize(sessionId);
      }
      emitSessionError(sessionId, message);
      emitSessionsChanged(sessionId, 'error');
    } finally {
      this.activeSessions.delete(sessionId);
    }
  }

  private finalizeChannelTurnInBackground(sessionId: string): void {
    queueMicrotask(() => {
      void this.finalizer.finalize(sessionId).catch((error) => {
        console.error('[HttpSessionExecutor] Channel finalizer failed:', error);
      });
    });
  }

  private resolveDirectApiConfig(agentRoleKey: string | null | undefined): DirectApiConfig | null {
    const resolvedRoleKey = resolveRuntimeAgentRoleKey(agentRoleKey);
    const appConfig = this.configStore.get<Record<string, unknown>>('app_config');
    const roles = resolveAgentRolesFromConfig(appConfig as Parameters<typeof resolveAgentRolesFromConfig>[0]);
    const role = roles[resolvedRoleKey];

    if (!role) {
      return null;
    }

    if (role.apiFormat !== 'openai') {
      throw new Error(`Role ${resolvedRoleKey} is configured as ${role.apiFormat}. Web direct executor currently only supports openai-compatible streaming.`);
    }

    const baseURL = role.apiUrl.trim();
    const model = role.modelId.trim();
    if (!baseURL || !model) {
      return null;
    }

    const apiKey = pickNextApiKey(role.apiKey, `web-session-executor:${resolvedRoleKey}`) || role.apiKey.trim();

    return {
      baseURL,
      apiKey,
      model,
      agentRoleKey: resolvedRoleKey,
      imageApiType: role.imageApiType,
    };
  }

  private ensureLatestUserMessage(sessionId: string, prompt: string, options: TurnOptions): void {
    const session = this.store.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found`);
    }

    const lastMessage = session.messages[session.messages.length - 1];
    if (lastMessage?.type === 'user' && lastMessage.content === prompt) {
      return;
    }

    const metadata: Record<string, unknown> = {};
    if (options.skillIds?.length) {
      metadata.skillIds = options.skillIds;
    }
    if (options.imageAttachments?.length) {
      metadata.imageAttachments = options.imageAttachments;
    }

    const userMessage = this.store.addMessage(sessionId, {
      type: 'user',
      content: prompt,
      metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
    });
    emitSessionMessage(sessionId, userMessage);
    emitSessionsChanged(sessionId, 'user-message');
  }

  private async buildSystemPrompt(
    sessionId: string,
    baseSystemPrompt: string,
    options: TurnOptions,
    mode: 'start' | 'continue' | 'channel'
  ): Promise<string> {
    // 【1.0链路】PROMPT-BUILD: 系统提示 = 显式 systemPrompt + 角色技能提示 + 连续性共享记忆提示。
    const session = this.store.getSession(sessionId);
    if (!session) {
      return baseSystemPrompt;
    }

    const promptSections: string[] = [];
    const mergedSkillIds = this.resolveMergedSkillIds(session, options);

    if (options.systemPrompt?.trim()) {
      promptSections.push(options.systemPrompt.trim());
    } else if (baseSystemPrompt.trim()) {
      promptSections.push(baseSystemPrompt.trim());
    }

    if (mergedSkillIds.length > 0 && this.buildSelectedSkillsPrompt) {
      const skillPrompt = await this.buildSelectedSkillsPrompt(mergedSkillIds);
      if (skillPrompt?.trim()) {
        promptSections.push(skillPrompt.trim());
      }
    }

    promptSections.push(...buildNativeCapabilitySystemPrompts({
      roleKey: resolveRuntimeAgentRoleKey(session.agentRoleKey),
      appConfig: this.configStore.get<Record<string, unknown>>('app_config') as Record<string, unknown> | null,
      readCurrentBrowserPage: () => readCurrentBrowserEyesStateFromConfigStore(this.configStore),
    }));

    const browserEyesFirstPrompt = this.buildBrowserEyesFirstPrompt(
      resolveRuntimeAgentRoleKey(session.agentRoleKey),
      mergedSkillIds
    );
    if (browserEyesFirstPrompt) {
      promptSections.push(browserEyesFirstPrompt);
    }

    const preloadedPageObservation = await this.buildPreloadedPageObservationPrompt(
      session,
      mergedSkillIds
    );
    if (preloadedPageObservation) {
      promptSections.push(preloadedPageObservation);
    }

    if (session.agentRoleKey) {
      const runtimeMcpAwareness = this.buildRuntimeMcpAwareness(resolveRuntimeAgentRoleKey(session.agentRoleKey));
      if (runtimeMcpAwareness) {
        promptSections.push(runtimeMcpAwareness);
      }

      const continuity = resolveContinuityBootstrap({
        db: this.store.getDatabase(),
        saveDb: this.store.getSaveFunction(),
        agentRoleKey: session.agentRoleKey,
        stateStore: this.configStore,
      });
      if (continuity.wakeupText.trim()) {
        promptSections.push(continuity.wakeupText.trim());
      }
      if (continuity.promptText.trim()) {
        promptSections.push(continuity.promptText.trim());
      }
    }

    return promptSections.filter((section) => section.trim()).join('\n\n');
  }

  private resolveMergedSkillIds(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    options: TurnOptions
  ): string[] {
    const selectedSkillIds = options.skillIds?.length ? options.skillIds : session.activeSkillIds;
    const roleBoundSkillIds = session.agentRoleKey
      ? this.readRuntimeRoleSkillIds(resolveRuntimeAgentRoleKey(session.agentRoleKey))
      : [];

    return Array.from(new Set([
      ...roleBoundSkillIds,
      ...(selectedSkillIds ?? []),
    ]));
  }

  private emitNativeAssistantMessage(sessionId: string, content: string, metadata?: Record<string, unknown>): void {
    const assistantMessage = this.store.addMessage(sessionId, {
      type: 'assistant',
      content,
      metadata: {
        isFinal: true,
        nativeTool: 'native-capability',
        ...(metadata ?? {}),
      },
    });
    emitSessionMessage(sessionId, assistantMessage);
  }

  private emitIntermediateAssistantMessage(
    sessionId: string,
    content: string,
    metadata?: Record<string, unknown>
  ): void {
    const trimmed = String(content || '').trim();
    if (!trimmed) {
      return;
    }

    const assistantMessage = this.store.addMessage(sessionId, {
      type: 'assistant',
      content: trimmed,
      metadata: {
        isFinal: false,
        stage: 'pre_tool',
        ...(metadata ?? {}),
      },
    });
    emitSessionMessage(sessionId, assistantMessage);
  }

  private async tryHandleNativeImaTurn(
    sessionId: string,
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    prompt: string,
    _skillIds: string[]
  ): Promise<boolean> {
    void session;
    void _skillIds;
    return tryHandleNativeCapabilityDirectTurn({
      prompt,
      emitResult: (content, metadata) => {
        this.emitNativeAssistantMessage(sessionId, content, metadata);
      },
    }, {
      roleKey: resolveRuntimeAgentRoleKey(session.agentRoleKey),
      appConfig: this.configStore.get<Record<string, unknown>>('app_config') as Record<string, unknown> | null,
      readCurrentBrowserPage: () => readCurrentBrowserEyesStateFromConfigStore(this.configStore),
    });
  }

  private buildBrowserEyesFirstPrompt(
    roleKey: AgentRoleKey,
    skillIds: string[]
  ): string | null {
    if (roleKey !== 'organizer' || !skillIds.includes(BLINGBLING_LITTLE_EYE_SKILL_ID)) {
      return null;
    }

    return [
      '## Browser Eyes First',
      '- If the current task is about understanding a webpage with likely readable DOM structure, inspect with `blingbling小眼睛` first.',
      '- Good first-look cases include forms, settings pages, admin panels, search/list/filter pages, and ordinary documentation-like pages.',
      '- Do not jump into heavy browser automation, repeated screenshots, or permission-heavy interaction before this first look unless direct action is already clearly necessary.',
      '- Escalate to heavier browser interaction only when `blingbling小眼睛` reports limits or when real page interaction is required.',
      '- If the page is canvas-heavy, visual-only, blocked, or DOM-poor, say that clearly and then switch strategy.',
    ].join('\n');
  }

  private async buildPreloadedPageObservationPrompt(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    skillIds: string[]
  ): Promise<string | null> {
    if (resolveRuntimeAgentRoleKey(session.agentRoleKey) !== 'organizer') {
      return null;
    }
    if (!skillIds.includes(BLINGBLING_LITTLE_EYE_SKILL_ID)) {
      return null;
    }

    const latestUserMessage = [...session.messages].reverse().find((message) => message.type === 'user');
    const resolvedTarget = this.resolveObservationTarget(latestUserMessage?.content || '');
    if (!resolvedTarget) {
      return null;
    }

    const observation = await this.runBlingblingObserver(resolvedTarget.target);
    if (!observation) {
      return null;
    }

    const compact = JSON.stringify(observation, null, 2);
    const clipped = compact.length > BLINGBLING_OBSERVER_PROMPT_MAX_CHARS
      ? `${compact.slice(0, BLINGBLING_OBSERVER_PROMPT_MAX_CHARS)}\n...`
      : compact;

    return [
      '## Preloaded Page Observation',
      resolvedTarget.description,
      'Treat it as helpful DOM-first reconnaissance, not perfect live-browser truth.',
      '```json',
      clipped,
      '```',
    ].join('\n');
  }

  private resolveObservationTarget(
    text: string
  ): {
    target: { mode: 'url' | 'file'; value: string };
    description: string;
  } | null {
    const explicitTarget = this.extractFirstObservationTarget(text);
    if (explicitTarget) {
      return {
        target: explicitTarget,
        description: `A lightweight first look was generated from the target in the user message using \`${BLINGBLING_LITTLE_EYE_SKILL_ID}\`.`,
      };
    }

    if (!this.userMessageLikelyRefersToCurrentPage(text)) {
      return null;
    }

    const currentPage = this.readCurrentBrowserEyesState();
    if (!currentPage) {
      return null;
    }

    return {
      target: { mode: 'url', value: currentPage.url },
      description: `A lightweight first look was generated from the current embedded browser page using \`${BLINGBLING_LITTLE_EYE_SKILL_ID}\`${currentPage.title ? ` (${currentPage.title})` : ''}.`,
    };
  }

  private extractFirstObservationTarget(text: string): { mode: 'url' | 'file'; value: string } | null {
    const rawText = String(text || '');

    const httpMatch = rawText.match(/https?:\/\/[^\s<>"')\]]+/i);
    if (httpMatch?.[0]) {
      return { mode: 'url', value: httpMatch[0] };
    }

    const fileUrlMatch = rawText.match(/file:\/\/\/?[^\s<>"')\]]+/i);
    if (fileUrlMatch?.[0]) {
      try {
        const parsedUrl = new URL(fileUrlMatch[0]);
        const decodedPath = decodeURIComponent(parsedUrl.pathname || '');
        const windowsPath = decodedPath.replace(/^\/([A-Za-z]:\/)/, '$1');
        return { mode: 'file', value: windowsPath };
      } catch {
        return null;
      }
    }

    const htmlPathMatch = rawText.match(/(?:[A-Za-z]:\\|\/)[^\s"'<>]+\.html?\b/i);
    if (htmlPathMatch?.[0]) {
      return { mode: 'file', value: htmlPathMatch[0] };
    }

    return null;
  }

  private userMessageLikelyRefersToCurrentPage(text: string): boolean {
    return /(current|this)\s+(page|webpage|tab|site)|look at (the|this) page|inspect (the|this) page|what(?:'s| is) on (the|this) page|当前页|这个页面|这个网页|看看(?:这个)?页面|看一下(?:这个)?页面|先看(?:这个)?页面/i.test(
      String(text || '')
    );
  }

  private readCurrentBrowserEyesState(): BrowserEyesCurrentPageState | null {
    try {
      const raw = this.configStore.get(BROWSER_EYES_CURRENT_PAGE_STORE_KEY) as BrowserEyesCurrentPageState | null;
      if (!raw || typeof raw !== 'object') {
        return null;
      }

      const url = String(raw.url || '').trim();
      const updatedAt = Number(raw.updatedAt || 0);
      if (!url || !Number.isFinite(updatedAt) || updatedAt <= 0) {
        return null;
      }

      if (Date.now() - updatedAt > BLINGBLING_CURRENT_PAGE_MAX_AGE_MS) {
        return null;
      }

      return {
        source: 'embedded-browser',
        url,
        title: typeof raw.title === 'string' ? raw.title.trim() : undefined,
        updatedAt,
      };
    } catch {
      return null;
    }
  }

  private resolveBlingblingObserverScriptPath(): string | null {
    const userDataPath = resolveRuntimeUserDataPath();
    const runtimePath = path.join(userDataPath, 'SKILLs', BLINGBLING_LITTLE_EYE_SKILL_ID, BLINGBLING_OBSERVER_SCRIPT);
    if (fs.existsSync(runtimePath)) {
      return runtimePath;
    }
    const projectPath = path.join(getProjectRoot(), 'SKILLs', BLINGBLING_LITTLE_EYE_SKILL_ID, BLINGBLING_OBSERVER_SCRIPT);
    return fs.existsSync(projectPath) ? projectPath : null;
  }

  private async runBlingblingObserver(target: { mode: 'url' | 'file'; value: string }): Promise<Record<string, unknown> | null> {
    const scriptPath = this.resolveBlingblingObserverScriptPath();
    if (!scriptPath) {
      return null;
    }

    const args = target.mode === 'url'
      ? [scriptPath, '--url', target.value, '--compact']
      : [scriptPath, '--file', target.value, '--compact'];

    const child = spawn(process.execPath, args, {
      cwd: path.dirname(path.dirname(scriptPath)),
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });

    let stdout = '';
    let stderr = '';
    const timeout = setTimeout(() => {
      child.kill('SIGTERM');
    }, BLINGBLING_OBSERVER_TIMEOUT_MS);

    return await new Promise((resolve) => {
      child.stdout.on('data', (chunk) => {
        stdout += chunk.toString();
      });
      child.stderr.on('data', (chunk) => {
        stderr += chunk.toString();
      });
      child.on('error', () => {
        clearTimeout(timeout);
        resolve(null);
      });
      child.on('close', (code) => {
        clearTimeout(timeout);
        if (code !== 0 || !stdout.trim()) {
          if (stderr.trim()) {
            console.warn('[HttpSessionExecutor] blingbling observer failed:', stderr.trim());
          }
          resolve(null);
          return;
        }

        try {
          const parsed = JSON.parse(stdout);
          if (!parsed || typeof parsed !== 'object') {
            resolve(null);
            return;
          }
          resolve(parsed);
        } catch {
          resolve(null);
        }
      });
    });
  }

  private readRuntimeRoleSkillIds(roleKey: AgentRoleKey): string[] {
    try {
      const userDataPath = resolveRuntimeUserDataPath();
      const indexPath = getRoleSkillsIndexPath(userDataPath, roleKey);
      if (!fs.existsSync(indexPath)) {
        return [];
      }

      const raw = fs.readFileSync(indexPath, 'utf8').trim();
      if (!raw) {
        return [];
      }

      const parsed = JSON.parse(raw) as { skills?: Array<{ id?: string; enabled?: boolean }> };
      if (!Array.isArray(parsed.skills)) {
        return [];
      }

      return parsed.skills
        .filter((entry) => entry && entry.enabled !== false)
        .map((entry) => String(entry.id ?? '').trim())
        .filter(Boolean);
    } catch (error) {
      console.warn('[HttpSessionExecutor] Failed to read runtime role skill ids:', error);
      return [];
    }
  }

  private buildRuntimeMcpAwareness(roleKey: AgentRoleKey): string | null {
    try {
      const userDataPath = resolveRuntimeUserDataPath();
      const snapshotPath = getRoleCapabilitySnapshotPath(userDataPath, roleKey);
      if (!fs.existsSync(snapshotPath)) {
        return null;
      }

      const raw = fs.readFileSync(snapshotPath, 'utf8').trim();
      if (!raw) {
        return null;
      }

      const parsed = JSON.parse(raw) as {
        runtimeMcpTools?: Array<{ name?: string }>;
      };
      const toolNames = Array.isArray(parsed.runtimeMcpTools)
        ? parsed.runtimeMcpTools
          .map((entry) => String(entry?.name ?? '').trim())
          .filter(Boolean)
        : [];

      if (toolNames.length === 0) {
        return null;
      }

      return [
        '## Runtime Capability Snapshot',
        `Configured external MCP tools for this role: ${toolNames.join(', ')}.`,
        'Important: this note only applies to external MCP tools from the runtime capability snapshot.',
        'It does not apply to built-in native capabilities such as browser eyes or IMA when those tools are actually available in the current session.',
        'Do not tell the user that browser eyes / IMA are unavailable just because external MCP auto-execution is limited.',
        'You may mention configured external MCP capabilities when asked, but do not claim you used one unless a real external MCP tool call occurred.',
      ].join('\n');
    } catch (error) {
      console.warn('[HttpSessionExecutor] Failed to read runtime MCP awareness:', error);
      return null;
    }
  }

  private needsBoundedToolLoop(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    prompt: string,
    mergedSkillIds: string[]
  ): boolean {
    const normalizedPrompt = String(prompt || '').trim().toLowerCase();
    if (!normalizedPrompt) {
      return false;
    }

    const hasBrowserEyesSkill = mergedSkillIds.includes(BLINGBLING_LITTLE_EYE_SKILL_ID);
    if (hasBrowserEyesSkill && this.promptLikelyNeedsBrowserTool(prompt)) {
      return true;
    }

    if (this.promptLikelyNeedsImaTool(prompt)) {
      return true;
    }

    if (this.promptLikelyNeedsMemoryTool(prompt)) {
      return true;
    }

    const likelyAgenticLoop = this.promptLikelyNeedsAgenticLoop(prompt);
    if (!likelyAgenticLoop) {
      return false;
    }

    const availableExecutorToolCount = this.buildExecutorTools(session, prompt).length;
    if (availableExecutorToolCount > 2) {
      return true;
    }

    if (mergedSkillIds.length > 0) {
      return true;
    }

    const roleKey = resolveRuntimeAgentRoleKey(session.agentRoleKey);
    const runtimeMcpCount = this.readRuntimeMcpToolCount(roleKey);
    if (runtimeMcpCount > 0) {
      return true;
    }

    if (session.sourceType === 'external' && (this.promptLikelyNeedsBrowserTool(prompt) || this.promptLikelyNeedsImaTool(prompt))) {
      return true;
    }

    return false;
  }

  private promptLikelyNeedsAgenticLoop(prompt: string): boolean {
    const normalized = String(prompt || '').trim();
    if (!normalized) {
      return false;
    }

    const hasActionVerb = /(帮我|帮忙|请你|请帮|请先|去|打开|查看|读取|搜索|查找|找出|列出|浏览|整理|分析|总结|归纳|保存|导出|创建|新建|修改|删除|更新|执行|运行|调用|使用|检查|排查|修复|验证|测试|搜一下|看看|看下|read|open|search|find|list|browse|summari[sz]e|analy[sz]e|save|export|create|update|delete|run|use|inspect|check|debug|fix|test)/i.test(
      normalized
    );
    const hasConcreteTarget = /(https?:\/\/|[A-Za-z]:\\|\/[^ \n\r\t]+|页面|网页|当前页|目录|文件|文档|链接|网址|笔记|对话|历史|记忆|工具|mcp|browser|playwright|ima|note|file|folder|directory|page|url|link|history|memory|tool|server)/i.test(
      normalized
    );

    return hasActionVerb && hasConcreteTarget;
  }

  private promptLikelyNeedsBrowserTool(prompt: string): boolean {
    return /(当前页|这个页面|这个网页|看(?:看|一下).*页面|观察.*页面|inspect.*page|observe.*page|analy[sz]e.*page|https?:\/\/|\.html?\b)/i.test(
      prompt
    );
  }

  private promptLikelyNeedsImaTool(prompt: string): boolean {
    return /(?:\bima\b|腾讯ima|ima笔记|ima\s*note)/i.test(prompt);
  }

  private promptLikelyNeedsMemoryTool(prompt: string): boolean {
    return /(之前|上次|还记得|昨天|前天|最近聊天|最近对话|历史对话|history|recent chats|conversation search|记住|记下来|更新记忆|删除记忆|memory)/i.test(
      prompt
    );
  }

  private readRuntimeMcpToolCount(roleKey: AgentRoleKey): number {
    try {
      const userDataPath = resolveRuntimeUserDataPath();
      const snapshotPath = getRoleCapabilitySnapshotPath(userDataPath, roleKey);
      if (!fs.existsSync(snapshotPath)) {
        return 0;
      }

      const raw = fs.readFileSync(snapshotPath, 'utf8').trim();
      if (!raw) {
        return 0;
      }

      const parsed = JSON.parse(raw) as {
        runtimeMcpTools?: unknown[];
      };
      return Array.isArray(parsed.runtimeMcpTools) ? parsed.runtimeMcpTools.length : 0;
    } catch {
      return 0;
    }
  }

  private async runBoundedToolLoop(
    sessionId: string,
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    prompt: string,
    systemPrompt: string,
    apiConfig: DirectApiConfig,
    streamState: StreamState,
    signal: AbortSignal
  ): Promise<void> {
    const toolDefinitions = this.buildExecutorTools(session, prompt);
    if (toolDefinitions.length === 0) {
      await this.runOpenAIStream(sessionId, session, systemPrompt, apiConfig, streamState, signal);
      return;
    }

    const timeoutController = new AbortController();
    const timeoutId = setTimeout(() => {
      timeoutController.abort(new Error('bounded-tool-loop-timeout'));
    }, BOUNDED_LOOP_MAX_DURATION_MS);
    const effectiveSignal = AbortSignal.any([signal, timeoutController.signal]);

    try {
      const messages = await this.buildOpenAIRequestMessages(session, systemPrompt);
      for (let step = 1; step <= BOUNDED_LOOP_MAX_STEPS; step += 1) {
        if (effectiveSignal.aborted) {
          throw abortReasonToError(effectiveSignal.reason, 'bounded tool loop aborted');
        }

        const responsePayload = await this.fetchOpenAIChatCompletion({
          apiConfig,
          messages,
          tools: toolDefinitions.map((tool) => tool.spec),
          toolChoice: 'auto',
          signal: effectiveSignal,
        });

        const toolCalls = extractAssistantToolCalls(responsePayload);
        const messageContent = normalizeAssistantMessageContent(
          responsePayload?.choices?.[0]?.message?.content
        );

        if (toolCalls.length === 0) {
          const output = extractAssistantOutput(responsePayload);
          if (output.text || output.generatedImages.length > 0) {
            this.appendAssistantOutput(sessionId, streamState, output);
            return;
          }
          if (messageContent && typeof messageContent === 'string' && messageContent.trim()) {
            this.appendAssistantOutput(sessionId, streamState, {
              text: messageContent,
              generatedImages: [],
            });
            return;
          }
          throw new Error('上游返回了空响应，未产出最终 assistant 内容。');
        }

        if (messageContent && messageContent.trim()) {
          this.emitIntermediateAssistantMessage(sessionId, messageContent, {
            toolCallCount: toolCalls.length,
          });
        }

        messages.push({
          role: 'assistant',
          content: messageContent,
          tool_calls: toolCalls,
        });

        for (const toolCall of toolCalls) {
          const resolvedTool = toolDefinitions.find((entry) => entry.name === toolCall.function.name);
          const toolInput = tryParseJson(toolCall.function.arguments) ?? {};
          this.emitToolUseMessage(sessionId, toolCall, toolInput);

          if (!resolvedTool) {
            const unsupportedText = `Unsupported executor tool: ${toolCall.function.name || '(empty)'}`;
            this.emitToolResultMessage(sessionId, toolCall, unsupportedText, true);
            messages.push({
              role: 'tool',
              tool_call_id: toolCall.id,
              content: unsupportedText,
            });
            continue;
          }

          const toolResult = await resolvedTool.handler(toolInput);
          this.emitToolResultMessage(sessionId, toolCall, toolResult.text, Boolean(toolResult.isError));
          messages.push({
            role: 'tool',
            tool_call_id: toolCall.id,
            content: toolResult.text,
          });
        }
      }

      throw new Error(`工具回环超过 ${BOUNDED_LOOP_MAX_STEPS} 步，已按安全边界停止。`);
    } finally {
      clearTimeout(timeoutId);
    }
  }

  private async fetchOpenAIChatCompletion(params: {
    apiConfig: DirectApiConfig;
    messages: OpenAIRequestMessage[];
    tools: Array<ExecutorToolDefinition['spec']>;
    toolChoice: 'auto' | 'required';
    signal: AbortSignal;
  }): Promise<any> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (params.apiConfig.apiKey.trim()) {
      headers.Authorization = `Bearer ${params.apiConfig.apiKey.trim()}`;
    }

    const response = await fetch(buildOpenAIChatCompletionsURL(params.apiConfig.baseURL), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: params.apiConfig.model,
        max_tokens: DEFAULT_OPENAI_MAX_TOKENS,
        stream: false,
        tool_choice: params.toolChoice,
        messages: params.messages,
        tools: params.tools,
      }),
      signal: params.signal,
    });

    if (!response.ok) {
      throw new Error(await buildUpstreamError(response));
    }

    return await response.json().catch(() => null);
  }

  private async buildOpenAIRequestMessages(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string
  ): Promise<OpenAIRequestMessage[]> {
    return await this.buildOpenAIMessages(session, systemPrompt);
  }

  private emitToolUseMessage(sessionId: string, toolCall: OpenAIToolCall, toolInput: Record<string, unknown>): void {
    const toolUseMessage = this.store.addMessage(sessionId, {
      type: 'tool_use',
      content: '',
      metadata: {
        toolName: toolCall.function.name,
        toolInput,
        toolUseId: toolCall.id,
      },
    });
    emitSessionMessage(sessionId, toolUseMessage);
  }

  private emitToolResultMessage(
    sessionId: string,
    toolCall: OpenAIToolCall,
    text: string,
    isError: boolean
  ): void {
    const toolResultMessage = this.store.addMessage(sessionId, {
      type: 'tool_result',
      content: text,
      metadata: {
        toolName: toolCall.function.name,
        toolResult: text,
        toolUseId: toolCall.id,
        isError,
        ...(isError ? { error: text } : {}),
      },
    });
    emitSessionMessage(sessionId, toolResultMessage);
  }

  private buildExecutorTools(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    prompt: string
  ): ExecutorToolDefinition[] {
    const roleKey = resolveRuntimeAgentRoleKey(session.agentRoleKey);
    const allowMemoryUserEdits = this.promptLikelyNeedsMemoryTool(prompt);
    const nativeCapabilityContext = {
      roleKey,
      appConfig: this.configStore.get<Record<string, unknown>>('app_config') as Record<string, unknown> | null,
      readCurrentBrowserPage: () => readCurrentBrowserEyesStateFromConfigStore(this.configStore),
    };

    const tools: ExecutorToolDefinition[] = [
      {
        name: 'conversation_search',
        spec: {
          type: 'function',
          function: {
            name: 'conversation_search',
            description: 'Search prior conversations by query and return compact <chat> blocks.',
            parameters: {
              type: 'object',
              properties: {
                query: { type: 'string' },
                max_results: { type: 'integer', minimum: 1, maximum: 10 },
                before: { type: 'string' },
                after: { type: 'string' },
              },
              required: ['query'],
              additionalProperties: false,
            },
          },
        },
        handler: async (args: {
          query: string;
          max_results?: number;
          before?: string;
          after?: string;
        }) => ({
          text: this.runConversationSearchTool(args, {
            agentRoleKey: session.agentRoleKey,
          }),
        }),
      },
      {
        name: 'recent_chats',
        spec: {
          type: 'function',
          function: {
            name: 'recent_chats',
            description: 'List recent chats for the current role bucket and return compact <chat> blocks.',
            parameters: {
              type: 'object',
              properties: {
                n: { type: 'integer', minimum: 1, maximum: 20 },
                sort_order: { type: 'string', enum: ['asc', 'desc'] },
                before: { type: 'string' },
                after: { type: 'string' },
              },
              additionalProperties: false,
            },
          },
        },
        handler: async (args: {
          n?: number;
          sort_order?: 'asc' | 'desc';
          before?: string;
          after?: string;
        }) => ({
          text: this.runRecentChatsTool(args, {
            agentRoleKey: session.agentRoleKey,
          }),
        }),
      },
    ];

    if (this.store.getConfig().memoryEnabled && allowMemoryUserEdits) {
      tools.push({
        name: 'memory_user_edits',
        spec: {
          type: 'function',
          function: {
            name: 'memory_user_edits',
            description: 'Manage user memories. action=list|add|update|delete.',
            parameters: {
              type: 'object',
              properties: {
                action: { type: 'string', enum: ['list', 'add', 'update', 'delete'] },
                id: { type: 'string' },
                text: { type: 'string' },
                confidence: { type: 'number', minimum: 0, maximum: 1 },
                status: { type: 'string', enum: ['created', 'stale', 'deleted'] },
                is_explicit: { type: 'boolean' },
                limit: { type: 'integer', minimum: 1, maximum: 200 },
                query: { type: 'string' },
              },
              required: ['action'],
              additionalProperties: false,
            },
          },
        },
        handler: async (args: {
          action: 'list' | 'add' | 'update' | 'delete';
          id?: string;
          text?: string;
          confidence?: number;
          status?: 'created' | 'stale' | 'deleted';
          is_explicit?: boolean;
          limit?: number;
          query?: string;
        }) => this.runMemoryUserEditsTool(args, {
          agentRoleKey: session.agentRoleKey,
          modelId: session.modelId,
        }),
      });
    }

    tools.push(...(
      createNativeCapabilitySdkTools((name, description, schema, handler) => ({
        name,
        spec: {
          type: 'function' as const,
          function: {
            name,
            description,
            parameters: normalizeToolParametersSchema(
              z.toJSONSchema(z.object(schema as Record<string, z.ZodTypeAny>), {
                target: 'draft-7',
                io: 'input',
              }) as Record<string, unknown>
            ),
          },
        },
        handler: async (args: any) => {
          const result = await handler(args);
          return {
            text: extractToolResultText(result),
            isError: Boolean(result?.isError),
          };
        },
      }), nativeCapabilityContext) as ExecutorToolDefinition[]
    ));

    return tools;
  }

  private formatChatSearchOutput(records: Array<{
    url: string;
    updatedAt: number;
    title: string;
    human: string;
    assistant: string;
  }>): string {
    if (records.length === 0) {
      return 'No matching chats found.';
    }

    return records.map((record) => {
      const updatedAtIso = new Date(record.updatedAt || Date.now()).toISOString();
      return [
        `<chat url="${escapeXml(record.url)}" updated_at="${updatedAtIso}">`,
        `Title: ${record.title || 'Untitled'}`,
        `Human: ${(record.human || '').trim() || '(empty)'}`,
        `Assistant: ${(record.assistant || '').trim() || '(empty)'}`,
        '</chat>',
      ].join('\n');
    }).join('\n\n');
  }

  private formatMemoryUserEditsResult(input: {
    action: 'list' | 'add' | 'update' | 'delete';
    successCount: number;
    failedCount: number;
    changedIds: string[];
    reason?: string;
    payload?: string;
  }): string {
    const parts = [
      `action=${input.action}`,
      `success=${input.successCount}`,
      `failed=${input.failedCount}`,
      `changed_ids=${input.changedIds.join(',') || '-'}`,
    ];
    if (input.reason) {
      parts.push(`reason=${input.reason}`);
    }
    if (input.payload) {
      parts.push(input.payload);
    }
    return parts.join('\n');
  }

  private runConversationSearchTool(args: {
    query: string;
    max_results?: number;
    before?: string;
    after?: string;
  }, identity?: { agentRoleKey?: string }): string {
    const chats = this.store.conversationSearch({
      query: args.query,
      maxResults: args.max_results,
      before: args.before,
      after: args.after,
      agentRoleKey: identity?.agentRoleKey,
    });
    return this.formatChatSearchOutput(chats);
  }

  private runRecentChatsTool(args: {
    n?: number;
    sort_order?: 'asc' | 'desc';
    before?: string;
    after?: string;
  }, identity?: { agentRoleKey?: string }): string {
    const chats = this.store.recentChats({
      n: args.n,
      sortOrder: args.sort_order,
      before: args.before,
      after: args.after,
      agentRoleKey: identity?.agentRoleKey,
    });
    return this.formatChatSearchOutput(chats);
  }

  private runMemoryUserEditsTool(args: {
    action: 'list' | 'add' | 'update' | 'delete';
    id?: string;
    text?: string;
    confidence?: number;
    status?: 'created' | 'stale' | 'deleted';
    is_explicit?: boolean;
    limit?: number;
    query?: string;
  }, identity?: { agentRoleKey?: string; modelId?: string }): { text: string; isError: boolean } {
    if (args.action === 'list') {
      const entries = this.store.listUserMemories({
        query: args.query,
        status: 'all',
        includeDeleted: true,
        limit: args.limit ?? 20,
        offset: 0,
        agentRoleKey: identity?.agentRoleKey,
      });
      const payload = entries.length === 0
        ? 'memories=(empty)'
        : entries
          .map((entry) => `${entry.id} | ${entry.status} | explicit=${entry.isExplicit ? 1 : 0} | ${entry.text}`)
          .join('\n');
      return {
        text: this.formatMemoryUserEditsResult({
          action: 'list',
          successCount: entries.length,
          failedCount: 0,
          changedIds: entries.map((entry) => entry.id),
          payload,
        }),
        isError: false,
      };
    }

    if (args.action === 'add') {
      const text = String(args.text || '').trim();
      if (!text) {
        return {
          text: this.formatMemoryUserEditsResult({
            action: 'add',
            successCount: 0,
            failedCount: 1,
            changedIds: [],
            reason: 'text is required',
          }),
          isError: true,
        };
      }
      const entry = this.store.createUserMemory({
        text,
        confidence: args.confidence,
        isExplicit: args.is_explicit ?? true,
        agentRoleKey: identity?.agentRoleKey,
        modelId: identity?.modelId,
      });
      return {
        text: this.formatMemoryUserEditsResult({
          action: 'add',
          successCount: 1,
          failedCount: 0,
          changedIds: [entry.id],
        }),
        isError: false,
      };
    }

    if (args.action === 'update') {
      if (!args.id?.trim()) {
        return {
          text: this.formatMemoryUserEditsResult({
            action: 'update',
            successCount: 0,
            failedCount: 1,
            changedIds: [],
            reason: 'id is required',
          }),
          isError: true,
        };
      }
      const updated = this.store.updateUserMemory({
        id: args.id.trim(),
        text: args.text,
        confidence: args.confidence,
        status: args.status,
        isExplicit: args.is_explicit,
      });
      if (!updated) {
        return {
          text: this.formatMemoryUserEditsResult({
            action: 'update',
            successCount: 0,
            failedCount: 1,
            changedIds: [],
            reason: 'memory not found',
          }),
          isError: true,
        };
      }
      return {
        text: this.formatMemoryUserEditsResult({
          action: 'update',
          successCount: 1,
          failedCount: 0,
          changedIds: [updated.id],
        }),
        isError: false,
      };
    }

    if (!args.id?.trim()) {
      return {
        text: this.formatMemoryUserEditsResult({
          action: 'delete',
          successCount: 0,
          failedCount: 1,
          changedIds: [],
          reason: 'id is required',
        }),
        isError: true,
      };
    }

    const deleted = this.store.deleteUserMemory(args.id.trim());
    return deleted
      ? {
        text: this.formatMemoryUserEditsResult({
          action: 'delete',
          successCount: 1,
          failedCount: 0,
          changedIds: [args.id.trim()],
        }),
        isError: false,
      }
      : {
        text: this.formatMemoryUserEditsResult({
          action: 'delete',
          successCount: 0,
          failedCount: 1,
          changedIds: [],
          reason: 'memory not found',
        }),
        isError: true,
      };
  }

  private async runOpenAIStream(
    sessionId: string,
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string,
    apiConfig: DirectApiConfig,
    streamState: StreamState,
    signal: AbortSignal
  ): Promise<void> {
    // {BREAKPOINT} DIRECT-EXECUTOR-SINGLE-SHOT
    // {FLOW} PHASE1-DIRECT-ONE-SHOT: 当前轻执行器这里只发起一次 openai-compatible chat completion，
    // 不做 assistant->tool->assistant 多轮代理循环，因此单个用户 turn 最终只会产出一个 assistant 消息。
    // {FLOW} PHASE1-NO-AUTO-TOOL-LOOP: browser eyes / IMA / MCP 若未命中 direct turn，则不会在这里自动进入工具回路。
    const messages = await this.buildOpenAIMessages(session, systemPrompt);
    const requestHash = buildTurnCacheKey({
      agentRoleKey: resolveIdentityAgentRoleKey(session.agentRoleKey),
      baseURL: apiConfig.baseURL,
      model: apiConfig.model,
      messages,
    });
    const cachedTurn = getTurnCacheEntry({
      db: this.store.getDatabase(),
      saveDb: this.store.getSaveFunction(),
      requestHash,
    });
    if (cachedTurn) {
      console.info(`[TurnCache] HIT session=${sessionId} role=${resolveIdentityAgentRoleKey(session.agentRoleKey)} model=${apiConfig.model}`);
      await this.replayCachedAssistantText(sessionId, streamState, cachedTurn.assistantText, signal);
      return;
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (apiConfig.apiKey.trim()) {
      headers.Authorization = `Bearer ${apiConfig.apiKey.trim()}`;
    }

    const response = await fetch(buildOpenAIChatCompletionsURL(apiConfig.baseURL), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: apiConfig.model,
        stream: true,
        stream_options: { include_usage: true },
        max_tokens: DEFAULT_OPENAI_MAX_TOKENS,
        messages,
      }),
      signal,
    });

    if (!response.ok) {
      throw new Error(await buildUpstreamError(response));
    }

    await consumeSSE(response, (payload) => {
      if (payload === '[DONE]') {
        return;
      }
      const parsed = tryParseJson(payload);
      const output = extractAssistantOutput(parsed);
      if (output.text || output.generatedImages.length > 0) {
        this.appendAssistantOutput(sessionId, streamState, output);
      }
    }, signal);

    if (streamState.content.trim()) {
      putTurnCacheEntry({
        db: this.store.getDatabase(),
        saveDb: this.store.getSaveFunction(),
        requestHash,
        agentRoleKey: resolveIdentityAgentRoleKey(session.agentRoleKey),
        baseURL: apiConfig.baseURL,
        model: apiConfig.model,
        assistantText: streamState.content,
      });
      console.info(`[TurnCache] STORE session=${sessionId} role=${resolveIdentityAgentRoleKey(session.agentRoleKey)} model=${apiConfig.model}`);
    }
  }

  private async runGoogleGenerateContent(
    sessionId: string,
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string,
    apiConfig: DirectApiConfig,
    streamState: StreamState,
    signal: AbortSignal
  ): Promise<void> {
    const requestBody = await this.buildGoogleGenerateContentRequest(session, systemPrompt);
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (apiConfig.apiKey.trim()) {
      headers.Authorization = `Bearer ${apiConfig.apiKey.trim()}`;
    }

    const response = await fetch(buildGoogleGenerateContentURL(apiConfig.baseURL, apiConfig.model, apiConfig.apiKey), {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
      signal,
    });

    if (!response.ok) {
      throw new Error(await buildUpstreamError(response));
    }

    const parsed = await response.json().catch(() => null);
    const output = extractAssistantOutput(parsed);
    if (output.text || output.generatedImages.length > 0) {
      this.appendAssistantOutput(sessionId, streamState, output);
    }
  }

  private async runOpenAIImagesGeneration(
    sessionId: string,
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string,
    apiConfig: DirectApiConfig,
    streamState: StreamState,
    signal: AbortSignal
  ): Promise<void> {
    const requestBody = await this.buildOpenAIImagesGenerationRequest(session, systemPrompt);
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (apiConfig.apiKey.trim()) {
      headers.Authorization = `Bearer ${apiConfig.apiKey.trim()}`;
    }

    const response = await fetch(buildOpenAIImagesGenerationURL(apiConfig.baseURL), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: apiConfig.model,
        ...requestBody,
      }),
      signal,
    });

    if (!response.ok) {
      throw new Error(await buildUpstreamError(response));
    }

    const parsed = await response.json().catch(() => null);
    const output = extractAssistantOutput(parsed);
    if (output.generatedImages.length > 0 && !output.text) {
      output.text = '已生成图片。';
    }
    if (output.text || output.generatedImages.length > 0) {
      this.appendAssistantOutput(sessionId, streamState, output);
    }
  }

  private appendAssistantOutput(sessionId: string, streamState: StreamState, output: AssistantOutput): void {
    if (!output.text && output.generatedImages.length === 0) {
      return;
    }

    if (!streamState.messageId) {
      const initialGeneratedImages = output.generatedImages.length > 0 ? output.generatedImages : undefined;
      const message = this.store.addMessage(sessionId, {
        type: 'assistant',
        content: '',
        metadata: {
          isStreaming: true,
          isFinal: false,
          ...(initialGeneratedImages ? { generatedImages: initialGeneratedImages } : {}),
        },
      });
      streamState.messageId = message.id;
      emitSessionMessage(sessionId, message);
    }

    if (output.text) {
      streamState.content += output.text;
    }
    if (output.generatedImages.length > 0) {
      for (const image of output.generatedImages) {
        const dedupeKey = buildGeneratedImageKey(image);
        if (streamState.generatedImageKeys.has(dedupeKey)) {
          continue;
        }
        streamState.generatedImageKeys.add(dedupeKey);
        streamState.generatedImages.push(image);
      }
    }
    const metadata: CoworkMessageMetadata = {
      ...(streamState.metadata || {}),
      isStreaming: true,
      isFinal: false,
      ...(streamState.generatedImages.length > 0 ? { generatedImages: streamState.generatedImages } : {}),
    };
    streamState.metadata = metadata;
    this.store.updateMessage(sessionId, streamState.messageId, {
      content: streamState.content,
      metadata,
    });
    emitSessionMessageUpdate(sessionId, streamState.messageId, streamState.content);
  }

  private async replayCachedAssistantText(
    sessionId: string,
    streamState: StreamState,
    content: string,
    signal: AbortSignal
  ): Promise<void> {
    if (!content.trim()) {
      return;
    }

    streamState.metadata = {
      ...(streamState.metadata || {}),
      cacheHit: true,
      cacheSource: 'turn_cache',
    };

    for (const chunk of splitTextForReplay(content)) {
      if (signal.aborted) {
        return;
      }
      this.appendAssistantOutput(sessionId, streamState, {
        text: chunk,
        generatedImages: [],
      });
      await sleep(CACHE_REPLAY_CHUNK_DELAY_MS);
    }
  }

  private finishAssistantMessage(sessionId: string, streamState: StreamState): void {
    if (!streamState.messageId) {
      return;
    }

    const metadata: CoworkMessageMetadata = {
      ...(streamState.metadata || {}),
      isStreaming: false,
      isFinal: true,
      ...(streamState.generatedImages.length > 0 ? { generatedImages: streamState.generatedImages } : {}),
    };
    this.store.updateMessage(sessionId, streamState.messageId, {
      content: streamState.content,
      metadata,
    });
    emitSessionMessageUpdate(sessionId, streamState.messageId, streamState.content);
  }

  private async buildOpenAIMessages(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string
  ): Promise<OpenAIMessage[]> {
    // 【1.0链路】RAW-CONTEXT-5: 原始对话正文只向上游转发最近 5 条，其余依赖共享记忆和系统提示承接。
    const messages: OpenAIMessage[] = [];
    if (systemPrompt.trim()) {
      messages.push({ role: 'system', content: systemPrompt.trim() });
    }

    const rawConversation = (await Promise.all(
      session.messages.map((message) => normalizeConversationMessage(message))
    ))
      .filter((message): message is OpenAIMessage => Boolean(message));

    // Keep only the latest raw conversation messages. Shared memory and baton
    // continuity are injected through the system prompt, not through full-chat replay.
    for (const message of rawConversation.slice(-FORWARDED_RAW_CONTEXT_MESSAGE_LIMIT)) {
      messages.push(message);
    }

    return messages;
  }

  private async buildGoogleGenerateContentRequest(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string
  ): Promise<Record<string, unknown>> {
    const openAIMessages = await this.buildOpenAIMessages(session, '');
    const contents = openAIMessages
      .filter((message) => message.role !== 'system')
      .map(convertOpenAIMessageToGoogleContent)
      .filter((message): message is Record<string, unknown> => Boolean(message));

    const requestBody: Record<string, unknown> = {
      contents,
    };

    if (systemPrompt.trim()) {
      requestBody.systemInstruction = {
        parts: [{ text: systemPrompt.trim() }],
      };
    }

    return requestBody;
  }

  private async buildOpenAIImagesGenerationRequest(
    session: NonNullable<ReturnType<CoworkStore['getSession']>>,
    systemPrompt: string
  ): Promise<Record<string, unknown>> {
    const latestUserMessage = [...session.messages].reverse().find((message) => message.type === 'user');
    const userPrompt = latestUserMessage
      ? await inlineAttachmentContent(latestUserMessage.content, extractImageAttachments(latestUserMessage.metadata).length > 0)
      : '';
    const imageAttachments = latestUserMessage ? extractImageAttachments(latestUserMessage.metadata) : [];
    const prompt = [systemPrompt.trim(), userPrompt.trim()].filter(Boolean).join('\n\n');
    const requestBody: Record<string, unknown> = {
      prompt,
    };

    if (imageAttachments.length === 1) {
      requestBody.image = `data:${imageAttachments[0].mimeType};base64,${imageAttachments[0].base64Data}`;
    } else if (imageAttachments.length > 1) {
      requestBody.image = imageAttachments.map((attachment) => `data:${attachment.mimeType};base64,${attachment.base64Data}`);
    }

    return requestBody;
  }

}

let webSessionExecutor: HttpSessionExecutor | null = null;

export function getOrCreateWebSessionExecutor(params: {
  store: CoworkStore;
  configStore: SqliteStore;
  buildSelectedSkillsPrompt?: SkillPromptBuilder | null;
}): HttpSessionExecutor {
  if (!webSessionExecutor) {
    webSessionExecutor = new HttpSessionExecutor(
      params.store,
      params.configStore,
      params.buildSelectedSkillsPrompt ?? null
    );
  }
  return webSessionExecutor;
}

type StreamState = {
  messageId: string | null;
  content: string;
  metadata: CoworkMessageMetadata | null;
  generatedImages: GeneratedImage[];
  generatedImageKeys: Set<string>;
};

function createStreamState(): StreamState {
  return {
    messageId: null,
    content: '',
    metadata: null,
    generatedImages: [],
    generatedImageKeys: new Set<string>(),
  };
}

function splitTextForReplay(content: string): string[] {
  if (content.length <= CACHE_REPLAY_CHUNK_SIZE) {
    return [content];
  }

  const chunks: string[] = [];
  let cursor = 0;
  while (cursor < content.length) {
    let next = Math.min(cursor + CACHE_REPLAY_CHUNK_SIZE, content.length);
    while (
      next < content.length &&
      next > cursor + Math.floor(CACHE_REPLAY_CHUNK_SIZE / 2) &&
      !/[\s,.!?;:，。！？；：]/.test(content[next - 1] || '')
    ) {
      next -= 1;
    }
    if (next <= cursor) {
      next = Math.min(cursor + CACHE_REPLAY_CHUNK_SIZE, content.length);
    }
    chunks.push(content.slice(cursor, next));
    cursor = next;
  }
  return chunks;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function normalizeConversationMessage(message: CoworkMessage): Promise<OpenAIMessage | null> {
  // {标记} P1-ATTACHMENT-PARSE: 本地聊天主链在这里把“输入文件: 路径”展开成可直接送模型的提取文本。
  const imageAttachments = extractImageAttachments(message.metadata);
  const normalizedUserContent = message.type === 'user'
    ? await inlineAttachmentContent(message.content, imageAttachments.length > 0)
    : message.content;

  if (!normalizedUserContent?.trim() && imageAttachments.length === 0) {
    return null;
  }

  if (message.type === 'user') {
    if (imageAttachments.length > 0) {
      const contentBlocks: OpenAIMessage['content'] = [];
      if (normalizedUserContent?.trim()) {
        contentBlocks.push({
          type: 'text',
          text: normalizedUserContent,
        });
      }
      for (const attachment of imageAttachments) {
        if (!attachment.base64Data?.trim() || !attachment.mimeType?.trim()) {
          continue;
        }
        contentBlocks.push({
          type: 'image_url',
          image_url: {
            url: `data:${attachment.mimeType};base64,${attachment.base64Data}`,
          },
        });
      }
      if (contentBlocks.length === 0) {
        return null;
      }
      return { role: 'user', content: contentBlocks };
    }

    return { role: 'user', content: normalizedUserContent };
  }

  if (message.type === 'assistant' && !message.metadata?.isThinking) {
    return { role: 'assistant', content: message.content };
  }

  return null;
}

function convertOpenAIMessageToGoogleContent(message: OpenAIMessage): Record<string, unknown> | null {
  const parts: Array<Record<string, unknown>> = [];

  if (typeof message.content === 'string') {
    if (message.content.trim()) {
      parts.push({ text: message.content.trim() });
    }
  } else {
    for (const part of message.content) {
      if (part.type === 'text') {
        if (part.text.trim()) {
          parts.push({ text: part.text.trim() });
        }
        continue;
      }

      if (part.type === 'image_url') {
        const dataUrlPayload = parseDataUrl(part.image_url.url);
        if (dataUrlPayload) {
          parts.push({
            inline_data: {
              mime_type: dataUrlPayload.mimeType,
              data: dataUrlPayload.base64Data,
            },
          });
        } else if (part.image_url.url.trim()) {
          parts.push({ text: `参考图片: ${part.image_url.url.trim()}` });
        }
      }
    }
  }

  if (parts.length === 0) {
    return null;
  }

  return {
    role: message.role === 'assistant' ? 'model' : 'user',
    parts,
  };
}

async function consumeSSE(
  response: Response,
  onPacket: (payload: string, eventName: string) => void,
  signal: AbortSignal
): Promise<void> {
  if (!response.body) {
    throw new Error('Upstream returned empty stream');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    if (signal.aborted) {
      return;
    }

    const { done, value } = await reader.read();
    if (done) {
      break;
    }

    buffer += decoder.decode(value, { stream: true });
    let boundary = findSseBoundary(buffer);
    while (boundary) {
      const packet = buffer.slice(0, boundary.index);
      buffer = buffer.slice(boundary.index + boundary.length);
      const parsed = parseSSEPacket(packet);
      if (parsed) {
        onPacket(parsed.payload, parsed.event);
      }
      boundary = findSseBoundary(buffer);
    }
  }

  if (buffer.trim()) {
    const parsed = parseSSEPacket(buffer);
    if (parsed) {
      onPacket(parsed.payload, parsed.event);
    }
  }
}

function parseSSEPacket(packet: string): { event: string; payload: string } | null {
  const lines = packet
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length === 0) {
    return null;
  }

  let event = 'message';
  const dataParts: string[] = [];

  for (const line of lines) {
    if (line.startsWith('event:')) {
      event = line.slice(6).trim() || 'message';
      continue;
    }
    if (line.startsWith('data:')) {
      dataParts.push(line.slice(5).trim());
    }
  }

  if (dataParts.length === 0) {
    return null;
  }

  return {
    event,
    payload: dataParts.join('\n'),
  };
}

function findSseBoundary(buffer: string): { index: number; length: number } | null {
  const lfBoundary = buffer.indexOf('\n\n');
  const crlfBoundary = buffer.indexOf('\r\n\r\n');

  if (lfBoundary === -1 && crlfBoundary === -1) {
    return null;
  }

  if (lfBoundary === -1) {
    return { index: crlfBoundary, length: 4 };
  }

  if (crlfBoundary === -1) {
    return { index: lfBoundary, length: 2 };
  }

  return lfBoundary < crlfBoundary
    ? { index: lfBoundary, length: 2 }
    : { index: crlfBoundary, length: 4 };
}

function tryParseJson(payload: string): any {
  try {
    return JSON.parse(payload);
  } catch {
    return null;
  }
}

function abortReasonToError(reason: unknown, fallbackMessage: string): Error {
  if (reason instanceof Error) {
    return reason;
  }
  if (typeof reason === 'string' && reason.trim()) {
    return new Error(reason);
  }
  return new Error(fallbackMessage);
}

function normalizeAssistantMessageContent(value: unknown): string | null {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed ? trimmed : null;
  }
  if (!Array.isArray(value)) {
    return null;
  }
  const text = value
    .map((part) => {
      if (typeof part === 'string') {
        return part;
      }
      if (typeof part?.text === 'string') {
        return part.text;
      }
      return '';
    })
    .join('')
    .trim();
  return text ? text : null;
}

function extractAssistantToolCalls(payload: any): OpenAIToolCall[] {
  const rawToolCalls = payload?.choices?.[0]?.message?.tool_calls;
  if (!Array.isArray(rawToolCalls)) {
    return [];
  }

  return rawToolCalls
    .map((item, index) => {
      const id = typeof item?.id === 'string' && item.id.trim()
        ? item.id.trim()
        : `tool_call_${index}`;
      const name = typeof item?.function?.name === 'string' ? item.function.name.trim() : '';
      if (!name) {
        return null;
      }
      const args = typeof item?.function?.arguments === 'string'
        ? item.function.arguments
        : JSON.stringify(item?.function?.arguments ?? {});
      return {
        id,
        type: 'function' as const,
        function: {
          name,
          arguments: args || '{}',
        },
      };
    })
    .filter((item): item is OpenAIToolCall => Boolean(item));
}

function extractToolResultText(result: any): string {
  if (typeof result?.text === 'string' && result.text.trim()) {
    return result.text;
  }

  const content = Array.isArray(result?.content) ? result.content : [];
  const text = content
    .map((item) => {
      if (typeof item?.text === 'string') {
        return item.text;
      }
      if (typeof item === 'string') {
        return item;
      }
      return '';
    })
    .filter(Boolean)
    .join('\n')
    .trim();

  if (text) {
    return text;
  }

  try {
    return JSON.stringify(result ?? null);
  } catch {
    return String(result ?? '');
  }
}

function normalizeToolParametersSchema(schema: Record<string, unknown>): Record<string, unknown> {
  const next = { ...schema };
  delete next.$schema;
  return next;
}

function escapeXml(value: string): string {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function extractOpenAITextDelta(payload: any): string {
  const delta = payload?.choices?.[0]?.delta;
  const content = delta?.content;
  if (typeof content === 'string') {
    return content;
  }
  if (Array.isArray(content)) {
    return content
      .map((item) => {
        if (typeof item === 'string') {
          return item;
        }
        if (typeof item?.text === 'string') {
          return item.text;
        }
        return '';
      })
      .join('');
  }
  return '';
}

function extractAssistantOutput(payload: any): AssistantOutput {
  const textChunks: string[] = [];
  const generatedImages: GeneratedImage[] = [];

  const pushText = (value: unknown): void => {
    if (typeof value === 'string' && value) {
      textChunks.push(value);
    }
  };

  const pushGeneratedImage = (image: GeneratedImage | null): void => {
    if (!image) {
      return;
    }
    generatedImages.push(image);
  };

  pushText(extractOpenAITextDelta(payload));

  const choiceDeltaContent = payload?.choices?.[0]?.delta?.content;
  if (Array.isArray(choiceDeltaContent)) {
    for (const part of choiceDeltaContent) {
      pushText(typeof part?.text === 'string' ? part.text : '');
      pushGeneratedImage(extractGeneratedImage(part));
    }
  }

  const choiceMessageContent = payload?.choices?.[0]?.message?.content;
  if (Array.isArray(choiceMessageContent)) {
    for (const part of choiceMessageContent) {
      pushText(typeof part?.text === 'string' ? part.text : '');
      pushGeneratedImage(extractGeneratedImage(part));
    }
  }

  if (Array.isArray(payload?.data)) {
    for (const item of payload.data) {
      pushGeneratedImage(extractGeneratedImage(item));
    }
  }

  if (Array.isArray(payload?.candidates)) {
    for (const candidate of payload.candidates) {
      const parts = candidate?.content?.parts;
      if (!Array.isArray(parts)) {
        continue;
      }
      for (const part of parts) {
        pushText(typeof part?.text === 'string' ? part.text : '');
        pushGeneratedImage(extractGeneratedImage(part));
      }
    }
  }

  const dedupedImages: GeneratedImage[] = [];
  const seen = new Set<string>();
  for (const image of generatedImages) {
    const key = buildGeneratedImageKey(image);
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    dedupedImages.push(image);
  }

  return {
    text: textChunks.join(''),
    generatedImages: dedupedImages,
  };
}

function extractGeneratedImage(value: unknown): GeneratedImage | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const record = value as Record<string, unknown>;
  const explicitUrl = typeof record.url === 'string' ? record.url.trim() : '';
  if (explicitUrl) {
    return {
      name: 'generated-image',
      url: explicitUrl,
    };
  }

  const b64Json = typeof record.b64_json === 'string' ? record.b64_json.trim() : '';
  if (b64Json) {
    return {
      name: 'generated-image',
      mimeType: 'image/png',
      base64Data: b64Json,
    };
  }

  const imageUrl = record.image_url;
  if (typeof imageUrl === 'string' && imageUrl.trim()) {
    const dataUrlPayload = parseDataUrl(imageUrl);
    if (dataUrlPayload) {
      return {
        name: 'generated-image',
        mimeType: dataUrlPayload.mimeType,
        base64Data: dataUrlPayload.base64Data,
      };
    }
    return {
      name: 'generated-image',
      url: imageUrl.trim(),
    };
  }

  if (imageUrl && typeof imageUrl === 'object') {
    const nestedUrl = typeof (imageUrl as Record<string, unknown>).url === 'string'
      ? ((imageUrl as Record<string, unknown>).url as string).trim()
      : '';
    if (nestedUrl) {
      const dataUrlPayload = parseDataUrl(nestedUrl);
      if (dataUrlPayload) {
        return {
          name: 'generated-image',
          mimeType: dataUrlPayload.mimeType,
          base64Data: dataUrlPayload.base64Data,
        };
      }
      return {
        name: 'generated-image',
        url: nestedUrl,
      };
    }
  }

  const inlineData = record.inline_data ?? record.inlineData;
  if (inlineData && typeof inlineData === 'object') {
    const inlineRecord = inlineData as Record<string, unknown>;
    const data = typeof inlineRecord.data === 'string' ? inlineRecord.data.trim() : '';
    const mimeType = typeof inlineRecord.mime_type === 'string'
      ? inlineRecord.mime_type.trim()
      : (typeof inlineRecord.mimeType === 'string' ? inlineRecord.mimeType.trim() : '');

    if (data) {
      return {
        name: 'generated-image',
        mimeType: mimeType || 'image/png',
        base64Data: data,
      };
    }
  }

  return null;
}

function buildGeneratedImageKey(image: GeneratedImage): string {
  return [
    image.name,
    image.mimeType || '',
    image.base64Data || '',
    image.url || '',
  ].join('|');
}

function parseDataUrl(value: string): { mimeType: string; base64Data: string } | null {
  const match = /^data:(.+?);base64,(.+)$/i.exec(value.trim());
  if (!match) {
    return null;
  }
  return {
    mimeType: match[1],
    base64Data: match[2],
  };
}

function buildGoogleGenerateContentURL(baseURL: string, model: string, apiKey: string): string {
  const normalized = baseURL.trim().replace(/\/+$/, '');
  let url = normalized;

  if (!url) {
    url = `/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  } else if (url.includes(':generateContent')) {
    url = normalized;
  } else if (/\/v1beta\/models\/[^/]+$/i.test(url) || /\/v1\/models\/[^/]+$/i.test(url)) {
    url = `${url}:generateContent`;
  } else if (url.endsWith('/v1beta/models') || url.endsWith('/v1/models') || url.endsWith('/models')) {
    url = `${url}/${encodeURIComponent(model)}:generateContent`;
  } else if (url.endsWith('/v1beta') || url.endsWith('/v1')) {
    const betaBase = url.endsWith('/v1') ? `${url.slice(0, -3)}v1beta` : url;
    url = `${betaBase}/models/${encodeURIComponent(model)}:generateContent`;
  } else {
    url = `${url}/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  }

  if (apiKey.trim() && !/[?&]key=/.test(url)) {
    const separator = url.includes('?') ? '&' : '?';
    url = `${url}${separator}key=${encodeURIComponent(apiKey.trim())}`;
  }

  return url;
}

function buildOpenAIImagesGenerationURL(baseURL: string): string {
  const normalized = baseURL.trim().replace(/\/+$/, '');
  if (!normalized) {
    return '/v1/images/generations';
  }
  if (normalized.endsWith('/images/generations')) {
    return normalized;
  }
  if (normalized.endsWith('/v1')) {
    return `${normalized}/images/generations`;
  }
  return `${normalized}/v1/images/generations`;
}

async function buildUpstreamError(response: Response): Promise<string> {
  const bodyText = await response.text().catch(() => '');
  const snippet = bodyText.trim().slice(0, 400);
  return snippet
    ? `Upstream request failed (${response.status}): ${snippet}`
    : `Upstream request failed (${response.status})`;
}

function resolveIdentityAgentRoleKey(value: string | null | undefined): string {
  const trimmed = typeof value === 'string' ? value.trim() : '';
  return trimmed || 'organizer';
}

function resolveRuntimeAgentRoleKey(value: string | null | undefined): AgentRoleKey {
  // {标记} P0-IDENTITY-BOUNDARY: 这里只做 4 主角色 runtime 配置解析，不代表 session / memory / thread 的真实身份。
  if (value === 'writer' || value === 'designer' || value === 'analyst') {
    return value;
  }
  return 'organizer';
}

function extractImageAttachments(metadata: CoworkMessageMetadata | null | undefined): ImageAttachment[] {
  const raw = metadata && typeof metadata === 'object'
    ? (metadata as Record<string, unknown>).imageAttachments
    : undefined;

  if (!Array.isArray(raw)) {
    return [];
  }

  return raw.flatMap((item) => {
    if (!item || typeof item !== 'object') {
      return [];
    }
    const record = item as Record<string, unknown>;
    const name = typeof record.name === 'string' ? record.name : 'image';
    const mimeType = typeof record.mimeType === 'string' ? record.mimeType : '';
    const base64Data = typeof record.base64Data === 'string' ? record.base64Data : '';
    if (!mimeType || !base64Data) {
      return [];
    }
    return [{
      name,
      mimeType,
      base64Data,
    }];
  });
}

function extractReferencedFilePaths(content: string): { promptText: string; filePaths: string[] } {
  const lines = content.split(/\r?\n/);
  const filePaths: string[] = [];
  const promptLines: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith(`${ATTACHMENT_INPUT_LABEL}:`)) {
      const filePath = trimmed.slice(ATTACHMENT_INPUT_LABEL.length + 1).trim();
      if (filePath) {
        filePaths.push(filePath);
      }
      continue;
    }
    promptLines.push(line);
  }

  return {
    promptText: promptLines.join('\n').trim(),
    filePaths,
  };
}

function isLikelyImagePath(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg'].includes(ext);
}

async function inlineAttachmentContent(content: string, hasInlineImagePayload: boolean): Promise<string> {
  const trimmed = content?.trim();
  if (!trimmed) {
    return '';
  }

  const { promptText, filePaths } = extractReferencedFilePaths(trimmed);
  if (filePaths.length === 0) {
    return trimmed;
  }

  const parsedBlocks: string[] = [];
  let totalChars = 0;

  for (const rawPath of Array.from(new Set(filePaths)).slice(0, MAX_PARSED_ATTACHMENT_COUNT)) {
    const resolvedPath = path.resolve(rawPath);
    const fileName = path.basename(resolvedPath) || resolvedPath;

    if (isLikelyImagePath(resolvedPath)) {
      parsedBlocks.push([
        `文件: ${fileName}`,
        `路径: ${resolvedPath}`,
        hasInlineImagePayload
          ? '说明: 该图片已作为视觉附件一并发送。'
          : '说明: 检测到图片文件路径，但当前消息未内联图片数据，无法在底层直接解析像素内容。',
      ].join('\n'));
      continue;
    }

    try {
      const stat = await fs.promises.stat(resolvedPath);
      if (!stat.isFile()) {
        parsedBlocks.push([
          `文件: ${fileName}`,
          `路径: ${resolvedPath}`,
          '解析结果: 目标不是普通文件。',
        ].join('\n'));
        continue;
      }

      if (stat.size > MAX_PARSED_ATTACHMENT_BYTES) {
        parsedBlocks.push([
          `文件: ${fileName}`,
          `路径: ${resolvedPath}`,
          `解析结果: 文件过大，已跳过底层解析（>${Math.floor(MAX_PARSED_ATTACHMENT_BYTES / (1024 * 1024))}MB）。`,
        ].join('\n'));
        continue;
      }

      const buffer = await fs.promises.readFile(resolvedPath);
      const parsed = await parseFile(fileName, buffer);
      if (!parsed.success || !parsed.text.trim()) {
        parsedBlocks.push([
          `文件: ${fileName}`,
          `路径: ${resolvedPath}`,
          `解析结果: ${parsed.error || '解析失败'}`,
        ].join('\n'));
        continue;
      }

      const remainingChars = MAX_PARSED_ATTACHMENT_TOTAL_CHARS - totalChars;
      if (remainingChars <= 0) {
        break;
      }

      const parsedText = parsed.text.slice(0, remainingChars);
      totalChars += parsedText.length;
      parsedBlocks.push([
        `文件: ${fileName}`,
        `路径: ${resolvedPath}`,
        `类型: ${parsed.fileType}`,
        '提取文本:',
        parsedText,
      ].join('\n'));
    } catch (error) {
      parsedBlocks.push([
        `文件: ${fileName}`,
        `路径: ${resolvedPath}`,
        `解析结果: ${error instanceof Error ? error.message : '读取失败'}`,
      ].join('\n'));
    }
  }

  if (parsedBlocks.length === 0) {
    return promptText || trimmed;
  }

  // {标记} P1-ATTACHMENT-PARSE: 常见文档在发给上游前先抽正文，避免只把文件路径丢给模型。
  return [
    promptText,
    '以下是当前消息附带文件的底层解析结果。优先依据提取文本理解内容，不要假装读取了未展示的原文件。',
    '<attached_files>',
    ...parsedBlocks,
    '</attached_files>',
  ]
    .filter((section) => section && section.trim())
    .join('\n\n');
}
