#!/usr/bin/env node
console.log('XIAS-AI短剧制作工具箱V1 - UNIVERSAL RELEASE');
console.log('This package is offline-ready and cross-platform.');
console.log('Included: skill/ and platforms/');
console.log('Startup: node skill/readme.js --quick');
