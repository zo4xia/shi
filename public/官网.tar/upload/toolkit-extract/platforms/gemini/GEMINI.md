# XIAS ShortDrama V1

You are using a commercial skill suite.
Initialize by reading `SKILL.md` first.
Always produce actionable outputs and keep encoding as UTF-8.
