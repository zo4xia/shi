# XIAS ShortDrama V1

## Qwen 初始化入口

1. 读取 `SKILL.md`
2. 先执行类型路由（类型2/类型3）
3. 输出必须可执行，禁止抽象建议
4. 保持 UTF-8 输出
