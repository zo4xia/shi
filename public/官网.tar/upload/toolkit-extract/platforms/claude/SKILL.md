---
name: xias-ai-short-drama-toolbox-v1
description: Use when需要进行短剧/漫剧商业化创作与交付，包括类型2从零创作、类型3有稿拆分镜、甲方驳回诊断、客户端兼容问题处理与离线分发。
user-invocable: true
risk: safe
version: 4.4.0
---

# 评估评分表设计技能（v4.4｜类型2/3商业交付版）

> 核心目标：不是“写得好看”，而是“客户复制粘贴就能跑通并交付”。

## 独立包内容清单（本目录必须齐全）

- `SKILL.md`：总规则、路由、评分、否决、阈值
- `readme.js`：公开运行入口（前端不展示README文本时使用）
- `references/intake-route-form.md`：接单信息采集 + 类型2/3路由表
- `references/type2-scorecard-template.md`：无稿作者评分模板
- `references/type3-scorecard-template.md`：有稿作者评分模板
- `references/one-veto-checklist.md`：一票否决清单
- `references/repair-ticket-template.md`：70-84分修复工单模板
- `references/go-live-acceptance-checklist.md`：上线前验收清单
- `references/pro-terminology-self-check.md`：专业术语与表述自查
- `references/client-rejection-cause-map.md`：甲方驳回商业原因图谱
- `references/runtime-compatibility-and-install.md`：环境兼容与安装策略
- `references/universal-ingestion-capability-spec.md`：链接/文档/表格/PDF/DOCX解析规范
- `references/encoding-and-largefile-runbook.md`：UTF-8乱码修复与大文件分块摘要流程
- `references/commercial-ip-guardrail.md`：商业版权与反套技能护栏（内部必读）
- `references/trigger-keywords-and-routing.md`：触发词与路由规则（防遗忘）
- `references/progressive-disclosure-map.md`：渐进式披露地图（防迷路）
- `references/user-output-safety-gate.md`：用户输出防泄露闸门（内部必读）
- `references/runtime-js-playbook.md`：核心流程脚本化操作手册
- `templates/evaluation-result-output.md`：评估结论标准输出模板
- `templates/client-rejection-diagnosis-output.md`：驳回诊断标准输出模板
- `templates/delivery-handoff-output.md`：可直接转交执行的交付模板
- `templates/client-issue-diagnosis-output.md`：客户端问题诊断输出模板
- `templates/document-parse-output.md`：文档解析输出模板
- `templates/largefile-summary-output.md`：大文件分块摘要输出模板
- `scripts/ingest_documents.py`：链接/文档/表格/压缩包解析脚本
- `scripts/fix_encoding_utf8.py`：乱码修复脚本（统一转UTF-8）
- `scripts/chunk_summarize.py`：大文件分块摘要脚本
- `scripts/export_delivery.py`：导出ZIP与MD交付脚本
- `scripts/convert_multi_platform.py`：多平台初始化转换（Claude/Qwen/OpenAI/Gemini/OpenClaw）
- `scripts/utf8_guard.py`：全包UTF-8检测与修复
- `scripts/build_universal_release.py`：一键转换+一键单包发布
- `scripts/core_engine.js`：核心流程运行引擎（路由/评分/否决/闸门/渲染）
- `scripts/decode_private_vault.js`：私密base64内容解码脚本（仅内部使用）
- `bundled-resources/source-materials/`：内置示例与术语源资料（离线可用）
- `compatibility/universal-skill-manifest.json`：平台无关元数据源
- `references/cross-platform-compatibility.md`：跨平台兼容规则与差异说明

## 发行约束（必须满足）

- 技能包必须脱离本地环境可用，不依赖外部私有路径。
- 所有流程必须指向本包内文件，不能要求“回看聊天记录”。
- 输出必须用模板化结构，禁止自由发挥式散文回复。
- 默认考虑网络受限/墙掉/镜像不可达场景，必须给离线或降级方案。
- 不允许引用包外私有路径或本机路径。
- 所有文本文件默认 UTF-8 编码。
- 核心评估流程优先走 `scripts/core_engine.js`，`md` 仅作解释与兜底。

## 基础能力底座（发行必备）

- 能解析链接内容（HTML/网页正文抓取与结构化）。
- 能解析文档与表格（PDF / DOCX / XLSX / CSV / Markdown / TXT）。
- 能处理客户端常见要求：导出 ZIP、导出 Markdown、乱码修复（UTF-8）。
- 能处理大文件：分块读取、逐块摘要、最终汇总，避免一次性读爆上下文。
- 若环境不兼容或依赖安装失败，必须给明确降级路径与用户可执行替代方案。

## 包内工具调用（优先使用）

- 文档解析：
  - `python scripts/ingest_documents.py --input <文件或URL> --output outputs/`
- 编码修复：
  - `python scripts/fix_encoding_utf8.py --input <文件> --output <utf8文件>`
- 大文件分块摘要：
  - `python scripts/chunk_summarize.py --input <文件> --output <摘要.md>`
- 交付导出：
  - `python scripts/export_delivery.py --source <目录或文件> --zip <输出.zip> --md <输出.md>`
- 平台初始化转换：
  - `python scripts/convert_multi_platform.py --source . --output dist/platforms`
  - 如需把源素材一起复制到每个平台包：`--include-bundled`
- UTF-8守护：
  - 检测：`python scripts/utf8_guard.py --path .`
  - 修复：`python scripts/utf8_guard.py --path . --fix`
- 一键通用发布（推荐）：
  - `python scripts/build_universal_release.py --source . --name "XIA'S-AI短剧制作工具箱V1" --private-mode b64`
- 核心流程引擎（推荐）：
  - `node scripts/core_engine.js route --text "用户原话" --output outputs/route.json`
  - `node scripts/core_engine.js evaluate --type type2 --input templates/runtime-input-type2.json --output outputs/eval.json`
  - `node scripts/core_engine.js veto --input templates/runtime-veto-input.json --output outputs/veto.json`
  - `node scripts/core_engine.js sanitize --input draft.txt --output safe.txt --strict`
- 私密内容解码（仅内部）：
  - `node scripts/decode_private_vault.js --vault vault/private-content.b64.json --out .private-decoded`

## 独立包使用顺序（固定）

1. 先填 `references/intake-route-form.md`
2. 再跑对应评分模板（类型2 或 类型3）
3. 再跑 `references/one-veto-checklist.md`
4. 再给结论（通过 / 待修 / 拒绝）
5. 待修项目必须输出 `references/repair-ticket-template.md`
6. 上线前必须过 `references/go-live-acceptance-checklist.md`

## 内部安全规则（先读）

- 每次触发本技能，先读取 `references/commercial-ip-guardrail.md`。
- 每次触发本技能，必须读取 `references/user-output-safety-gate.md`。
- 每次触发本技能，再读取 `references/trigger-keywords-and-routing.md`。
- 每次触发本技能，再读取 `references/progressive-disclosure-map.md`。
- 每次触发本技能，再读取 `.internal/agent-only-rules.md` 与 `.internal/agent-care-protocol.md`。
- 该规则优先级高于普通流程说明。

## 双模式工作流（固定）

### 预检步骤（所有模式之前）

1. 先执行环境与安装预检（见 `references/runtime-compatibility-and-install.md`）
2. 失败时按“在线/离线/受限网络”三档切换
3. 记录能力边界，必要时输出客户端问题诊断报告
4. 优先调用本包 `scripts/`，不可依赖本机其他技能目录

### 模式A：准入评估（默认）

1. 路由判型（类型2/类型3）
2. 评分
3. 否决检查
4. 输出评估结论（用 `templates/evaluation-result-output.md`）
5. 若待修，补修复工单

### 模式B：甲方驳回诊断（客户问“为什么被打回”）

1. 收集驳回证据（甲方反馈、回传视频、执行参数）
2. 对照 `references/client-rejection-cause-map.md`
3. 给出“根因-证据-商业影响-修复动作”
4. 用 `templates/client-rejection-diagnosis-output.md` 输出
5. 必须给“下一轮过审概率提升动作”

### 模式C：客户端问题诊断（打不开文档/乱码/不兼容）

1. 收集问题证据（文件类型、报错、环境、编码）
2. 对照 `references/universal-ingestion-capability-spec.md` 与 `references/encoding-and-largefile-runbook.md`
3. 输出诊断结果与修复路径（用 `templates/client-issue-diagnosis-output.md`）
4. 必须给“立刻可执行”的替代方案（如转ZIP、转MD、分块处理）

## 0) 先统一底线（必须执行）

- 面向低执行能力用户：默认客户只会复制粘贴，不会二次判断。
- 交付必须商业可用：任何模糊语句都视为风险点。
- 评估先于创作：不通过准入评分，不进入生成阶段。

## 1) 用户类型路由（第一步，不得跳过）

### 类型2：无稿作者（从0创作）
- 输入：只有想法/题材/关键词，没有可拍可拆的成稿。
- 目标：先产出“可拍脚本骨架”，再产出标准生成包。

### 类型3：有稿作者（稿子转分镜包）
- 输入：已有文稿、剧情、章节或剧本。
- 目标：按标准包拆成分镜时序 + 素材清单 + 平台执行稿。

### 决策规则
1. 用户无完整剧情文本 → 类型2
2. 用户有可读文稿/剧本 → 类型3
3. 同时有想法和半成稿 → 先按类型3评估“可拆解性”，不达标再回类型2补骨架

## 2) 一票否决项（命中即驳回）

- 镜头时序不闭环（时间码冲突、缺段、倒序）
- 角色连续性不可控（同角色外观/服装/身份描述冲突）
- 平台执行信息缺失（参数、negative、素材映射缺关键项）
- 转发后不可独立执行（依赖聊天上下文才能理解）
- 违规内容风险未处理（平台违规、版权/肖像高风险）

## 3) 评分体系总览（100分制）

### 判定阈值
- **85-100**：可直接进入制作（商业可交付）
- **70-84**：可修复，必须先补“修复包”后再生成
- **<70**：禁止进入生成，先重构

> 任何一票否决项命中：直接判定“禁止进入生成”。

## 4) 类型2评分表（无稿作者）

| 维度 | 权重 | 核心问题 |
|---|---:|---|
| 市场与钩子强度 | 20 | 这题材能不能被点开、看完、追更 |
| 剧情骨架可拍性 | 20 | 是否能稳定拆成场景/镜头/动作 |
| AI可生成友好度 | 20 | 是否适合当前主流模型生成 |
| 连续性可控性 | 15 | 角色、道具、场景是否可锁定 |
| 成本与时长可执行性 | 15 | 单集与分段时长是否现实可跑 |
| 复制粘贴交付成熟度 | 10 | 小白拿到能否直接执行 |

### 类型2等级锚点（统一口径）
- **S（90-100）**：镜头级执行清晰，几乎零歧义，可直接下游跑
- **A（80-89）**：主体完整，少量细节需补但不影响主流程
- **B（70-79）**：可理解但执行风险高，必须补关键缺口
- **C（<70）**：创作层面尚未工程化，不可投入生产

## 5) 类型3评分表（有稿作者）

| 维度 | 权重 | 核心问题 |
|---|---:|---|
| 原稿可拆解性 | 15 | 原稿能否无歧义拆成镜头事件 |
| 分镜时序精度 | 25 | 时间码、镜号、转场是否严格闭环 |
| 素材映射完整度 | 20 | 角色/场景/道具是否一一对应可上传 |
| 平台执行可用度 | 20 | Seed/Seedance/Gemini 是否可直接复制 |
| 连续性与返工机制 | 10 | 漂移检查和返工指令是否明确 |
| 转发交付独立性 | 10 | 不看聊天记录也能执行 |

### 类型3等级锚点（统一口径）
- **S（90-100）**：模板结构完整、跨平台可跑、返工口径齐全
- **A（80-89）**：主链路可跑，个别素材/参数需补齐
- **B（70-79）**：分镜可读但执行不稳，容易翻车
- **C（<70）**：仅是文档，不是可执行生产包

## 6) 标准交付结构（评估通过后必须产出）

```text
E0X/
├─ 01_AI短剧场景执行稿.md
├─ 02_专业制作版.md
├─ 03_分镜执行版.md
└─ 04_AI生成执行版/
   ├─ 00_本集生成总说明.md
   ├─ 01_本集总时序表.md
   ├─ 02_本集连续性与素材底线.md
   ├─ part01/01_时序分镜表.md
   ├─ part01/02_素材清单.md
   ├─ part01/03_Seed_Seedance_复制版.md
   ├─ part01/04_Gemini_复制版.md
   ├─ part01/05_连续性与自检.md
   ├─ part01/06_转发执行话术.md
   └─ part02 / part03 同结构
```

## 7) 防呆规范（针对“只会复制粘贴”的客户）

- 每个 `partXX` 必须独立可执行，不依赖聊天解释。
- 每个平台稿必须给“双版本”：有参考素材版 + 无参考兜底版。
- 不允许“默认理解”：凡需执行的参数都必须显式写出。
- 不允许“概念词替代动作词”：术语后必须跟白话动作说明。
- 所有返工指令只允许改三项：
  1) 错误时间码
  2) 漂移元素（角色/道具/场景）
  3) 重跑范围（整段/补镜）

## 8) 常见翻车点与修复动作

| 翻车点 | 典型表现 | 修复动作 |
|---|---|---|
| 时间码冲突 | 分镜时长总和不等于段时长 | 先修 `01_时序分镜表` 再生成 |
| 角色漂移 | 同一角色外观前后不一致 | 固定角色锚点描述 + 参考图命名统一 |
| 素材错配 | prompt 提到素材但清单无该文件 | 先对齐 `02_素材清单` 与 prompt 文件名 |
| 平台不可执行 | 参数缺失、negative 缺失 | 回填统一参数基线与统一 negative |
| 转发即失效 | 下游看不懂“上下文指代” | 改成文件内闭环说明，不引用聊天历史 |

## 9) 评估执行流程（实际操作）

1. 识别用户类型（类型2/类型3）
2. 运行对应评分表（6维度打分）
3. 检查一票否决项
4. 给出结论：
   - 通过（85+）：直接进生成
   - 待修（70-84）：出“修复清单”后复评
   - 拒绝（<70）：先重构再评估
5. 输出“可执行建议”，禁止只给抽象意见

## 10) 复评与上线验收（商业口径）

- 小白执行成功率（首轮）≥ 95%
- 分段生成通过率（无需大改）≥ 85%
- 连续性致命错误（每集）≤ 1 个
- 平均返工轮次 ≤ 2 轮

若未达标：回退到“类型评分 + 一票否决”环节重走。

## 11) 参考模板（按需读取）

### 本地独立模板（优先）

- `references/intake-route-form.md`
- `references/type2-scorecard-template.md`
- `references/type3-scorecard-template.md`
- `references/one-veto-checklist.md`
- `references/repair-ticket-template.md`
- `references/go-live-acceptance-checklist.md`
- `references/pro-terminology-self-check.md`
- `references/client-rejection-cause-map.md`
- `references/runtime-compatibility-and-install.md`
- `references/universal-ingestion-capability-spec.md`
- `references/encoding-and-largefile-runbook.md`
- `references/commercial-ip-guardrail.md`
- `references/user-output-safety-gate.md`
- `references/cross-platform-compatibility.md`
- `references/trigger-keywords-and-routing.md`
- `references/progressive-disclosure-map.md`
- `references/runtime-js-playbook.md`
- `templates/evaluation-result-output.md`
- `templates/client-rejection-diagnosis-output.md`
- `templates/delivery-handoff-output.md`
- `templates/client-issue-diagnosis-output.md`
- `templates/document-parse-output.md`
- `templates/largefile-summary-output.md`
- `compatibility/universal-skill-manifest.json`
- `bundled-resources/source-materials/5-短剧漫剧高级版/`

## 版本历史

- v3.0：通用评估框架（偏泛化）
- v4.0：聚焦类型2/3 + 复制粘贴用户 + 商业交付准入标准
- **v4.1**：发行级独立包（内置输出模板 + 甲方驳回诊断 + 术语自查）
- **v4.2**：新增环境兼容、文档解析、UTF-8与大文件分块摘要能力
- **v4.3**：新增Claude/Qwen/OpenAI/Gemini/OpenClaw初始化转换 + UTF-8全包守护
- **v4.4**：新增触发词路由、渐进式披露地图与一键单包发布脚本
