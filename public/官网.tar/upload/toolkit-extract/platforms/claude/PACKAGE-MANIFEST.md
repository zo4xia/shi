# Package Manifest (Offline Commercial Release)

## Core
- `SKILL.md`
- `PACKAGE-MANIFEST.md`
- `XIAS-AI短剧制作工具箱V1-作者说明.md`
- `readme.js`

## References
- `references/intake-route-form.md`
- `references/type2-scorecard-template.md`
- `references/type3-scorecard-template.md`
- `references/one-veto-checklist.md`
- `references/repair-ticket-template.md`
- `references/go-live-acceptance-checklist.md`
- `references/pro-terminology-self-check.md`
- `references/client-rejection-cause-map.md`
- `references/runtime-compatibility-and-install.md`
- `references/universal-ingestion-capability-spec.md`
- `references/encoding-and-largefile-runbook.md`
- `references/commercial-ip-guardrail.md`
- `references/user-output-safety-gate.md`
- `references/cross-platform-compatibility.md`
- `references/trigger-keywords-and-routing.md`
- `references/progressive-disclosure-map.md`
- `references/runtime-js-playbook.md`

## Templates
- `templates/evaluation-result-output.md`
- `templates/client-rejection-diagnosis-output.md`
- `templates/delivery-handoff-output.md`
- `templates/client-issue-diagnosis-output.md`
- `templates/document-parse-output.md`
- `templates/largefile-summary-output.md`
- `templates/runtime-input-type2.json`
- `templates/runtime-input-type3.json`
- `templates/runtime-veto-input.json`

## Scripts
- `scripts/ingest_documents.py`
- `scripts/fix_encoding_utf8.py`
- `scripts/chunk_summarize.py`
- `scripts/export_delivery.py`
- `scripts/convert_multi_platform.py`
- `scripts/utf8_guard.py`
- `scripts/build_universal_release.py`
- `scripts/core_engine.js`
- `scripts/decode_private_vault.js`
- `scripts/public_pack_rules.json`
- `scripts/requirements-optional.txt`

## Compatibility
- `compatibility/universal-skill-manifest.json`

## Bundled Source Materials
- `bundled-resources/source-materials/5-短剧漫剧高级版/`
- `bundled-resources/source-materials/单集短剧-分镜-剪辑成品输出标准模板/`
- `bundled-resources/source-materials/术语指南与镜头语言/`

## Packaging Rule
- Do not remove any file listed above.
- Do not depend on paths outside this folder.
- This package must work in offline or restricted-network environments.
