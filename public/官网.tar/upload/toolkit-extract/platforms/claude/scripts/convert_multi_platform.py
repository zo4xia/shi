#!/usr/bin/env python3
import argparse
import json
import shutil
from pathlib import Path

PUBLIC_RULES_FILE = Path("scripts") / "public_pack_rules.json"


def load_public_rules(source: Path):
    rules_path = source / PUBLIC_RULES_FILE
    if not rules_path.exists():
        return {"sensitive_relative_paths": [], "sensitive_prefixes": []}
    return json.loads(rules_path.read_text(encoding="utf-8"))


def is_sensitive(relative_posix: str, rules: dict):
    if relative_posix in set(rules.get("sensitive_relative_paths", [])):
        return True
    for prefix in rules.get("sensitive_prefixes", []):
        if relative_posix.startswith(prefix):
            return True
    return False

def read_manifest(source: Path):
    manifest_path = source / "compatibility" / "universal-skill-manifest.json"
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def copy_common_assets(source: Path, target: Path, include_bundled: bool, rules: dict):
    folders = ["references", "templates", "scripts", "compatibility"]
    if include_bundled:
        folders.append("bundled-resources")
    for folder in folders:
        src = source / folder
        if src.exists():
            dst = target / folder
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
    for file_name in ["PACKAGE-MANIFEST.md", "XIAS-AI短剧制作工具箱V1-作者说明.md"]:
        src = source / file_name
        if src.exists():
            shutil.copy2(src, target / file_name)
    # Copy runnable public readme
    readme_js = source / "readme.js"
    if readme_js.exists():
        shutil.copy2(readme_js, target / "readme.js")
    # Strip sensitive files from public output
    for p in list(target.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(target).as_posix()
        if is_sensitive(rel, rules):
            p.unlink()


def read_skill(source: Path):
    return (source / "SKILL.md").read_text(encoding="utf-8")


def write_text(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")


def render_openai_yaml(manifest: dict):
    display_name = manifest.get("display_name", "")
    short_description = manifest.get("short_description", "")
    default_prompt = manifest.get("default_prompt", "")
    return (
        "version: 1\n"
        "interface:\n"
        f"  display_name: \"{display_name}\"\n"
        f"  short_description: \"{short_description}\"\n"
        f"  default_prompt: \"{default_prompt}\"\n"
    )


def render_qwen_init(manifest: dict):
    return (
        f"# {manifest.get('display_name','')}\n\n"
        "## Qwen 初始化入口\n\n"
        "1. 读取 `SKILL.md`\n"
        "2. 先执行类型路由（类型2/类型3）\n"
        "3. 输出必须可执行，禁止抽象建议\n"
        "4. 保持 UTF-8 输出\n"
    )


def render_gemini_init(manifest: dict):
    return (
        f"# {manifest.get('display_name','')}\n\n"
        "You are using a commercial skill suite.\n"
        "Initialize by reading `SKILL.md` first.\n"
        "Always produce actionable outputs and keep encoding as UTF-8.\n"
    )


def render_openclaw_init(manifest: dict):
    payload = {
        "name": manifest.get("display_name", ""),
        "skill": manifest.get("skill_name", ""),
        "entry": manifest.get("entry_file", "SKILL.md"),
        "encoding": "utf-8",
        "init_rules": [
            "read_skill_first",
            "route_type2_or_type3",
            "output_actionable_only"
        ]
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def build_target(source: Path, output_root: Path, target: str, manifest: dict, skill_text: str, include_bundled: bool, rules: dict):
    target_dir = output_root / target
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    copy_common_assets(source, target_dir, include_bundled=include_bundled, rules=rules)

    # Base SKILL
    write_text(target_dir / "SKILL.md", skill_text)

    if target == "openai":
        write_text(target_dir / "agents" / "openai.yaml", render_openai_yaml(manifest))
    elif target == "qwen":
        write_text(target_dir / "QWEN_INIT.md", render_qwen_init(manifest))
    elif target == "gemini":
        write_text(target_dir / "GEMINI.md", render_gemini_init(manifest))
    elif target == "openclaw":
        write_text(target_dir / "openclaw.init.json", render_openclaw_init(manifest))
    elif target == "claude":
        # Claude already compatible with SKILL.md; add lightweight init helper
        write_text(
            target_dir / "CLAUDE_INIT.md",
            "Read `SKILL.md` first. Use type routing and actionable outputs only.\n",
        )

    write_text(
        target_dir / "target-readme.js",
        (
            "#!/usr/bin/env node\n"
            f"console.log('Target Package: {target}');\n"
            "console.log('Generated from universal manifest.');\n"
            "console.log('Encoding: UTF-8');\n"
            f"console.log('Bundled resources copied: {'yes' if include_bundled else 'no'}');\n"
        ),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=".", help="Skill root directory")
    parser.add_argument("--output", default="dist/platforms", help="Output directory")
    parser.add_argument("--include-bundled", action="store_true", help="Copy bundled-resources into each target package")
    args = parser.parse_args()

    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)

    manifest = read_manifest(source)
    rules = load_public_rules(source)
    skill_text = read_skill(source)
    targets = manifest.get("targets", ["claude", "qwen", "openai", "gemini", "openclaw"])
    for target in targets:
        build_target(source, output, target, manifest, skill_text, include_bundled=args.include_bundled, rules=rules)

    summary = {
        "source": str(source),
        "output": str(output),
        "targets": targets,
        "encoding": "utf-8",
        "include_bundled": args.include_bundled,
        "sensitive_strip_enabled": True
    }
    write_text(output / "conversion-summary.json", json.dumps(summary, ensure_ascii=False, indent=2))
    print(str(output))


if __name__ == "__main__":
    main()
