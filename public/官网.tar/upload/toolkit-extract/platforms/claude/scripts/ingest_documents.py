#!/usr/bin/env python3
import argparse
import csv
import html
import json
import os
import re
import sys
import zipfile
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen


ENCODINGS = ["utf-8", "utf-8-sig", "gbk", "gb18030", "utf-16", "latin-1"]


def read_text_with_fallback(path: Path):
    raw = path.read_bytes()
    for encoding in ENCODINGS:
        try:
            return raw.decode(encoding), encoding, None
        except Exception:
            pass
    return "", None, "decode_failed"


def html_to_text(content: str):
    content = re.sub(r"(?is)<script.*?>.*?</script>", " ", content)
    content = re.sub(r"(?is)<style.*?>.*?</style>", " ", content)
    content = re.sub(r"(?is)<[^>]+>", " ", content)
    content = html.unescape(content)
    content = re.sub(r"\s+", " ", content).strip()
    return content


def read_url(url: str):
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req, timeout=20) as resp:
        data = resp.read()
        content_type = resp.headers.get("Content-Type", "")
    text = ""
    encoding = None
    for enc in ENCODINGS + ["utf-8"]:
        try:
            text = data.decode(enc)
            encoding = enc
            break
        except Exception:
            continue
    if not text:
        text = data.decode("latin-1", errors="replace")
        encoding = "latin-1"
    if "html" in content_type.lower() or "<html" in text.lower():
        text = html_to_text(text)
    return {
        "kind": "url",
        "source": url,
        "encoding": encoding,
        "content_type": content_type,
        "text": text,
        "error": None,
    }


def read_csv_file(path: Path, limit_rows=200):
    text, encoding, err = read_text_with_fallback(path)
    if err:
        return {"error": err, "text": ""}
    rows = []
    for idx, row in enumerate(csv.reader(text.splitlines())):
        rows.append(row)
        if idx + 1 >= limit_rows:
            break
    return {"error": None, "encoding": encoding, "rows": rows}


def rows_to_markdown(rows):
    if not rows:
        return ""
    width = max(len(row) for row in rows)
    normalized = [row + [""] * (width - len(row)) for row in rows]
    header = normalized[0]
    lines = [
        "| " + " | ".join(header) + " |",
        "| " + " | ".join(["---"] * width) + " |",
    ]
    for row in normalized[1:]:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def read_docx(path: Path):
    try:
        import docx  # type: ignore
        doc = docx.Document(str(path))
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        return {"text": text, "engine": "python-docx", "error": None}
    except Exception:
        try:
            with zipfile.ZipFile(path, "r") as zf:
                xml_data = zf.read("word/document.xml").decode("utf-8", errors="replace")
            xml_data = re.sub(r"</w:p>", "\n", xml_data)
            xml_data = re.sub(r"<[^>]+>", "", xml_data)
            xml_data = html.unescape(xml_data)
            xml_data = re.sub(r"\n{3,}", "\n\n", xml_data).strip()
            return {"text": xml_data, "engine": "zip-xml-fallback", "error": None}
        except Exception as exc:
            return {"text": "", "engine": None, "error": f"docx_read_failed:{exc}"}


def read_pdf(path: Path):
    try:
        from pypdf import PdfReader  # type: ignore
        reader = PdfReader(str(path))
        pages = []
        for idx, page in enumerate(reader.pages):
            pages.append(f"## Page {idx + 1}\n{page.extract_text() or ''}".strip())
        return {"text": "\n\n".join(pages), "engine": "pypdf", "error": None}
    except Exception as exc:
        return {"text": "", "engine": None, "error": f"pdf_read_failed:{exc}"}


def read_xlsx(path: Path, limit_rows=200):
    try:
        from openpyxl import load_workbook  # type: ignore
        wb = load_workbook(filename=str(path), read_only=True, data_only=True)
        blocks = []
        for ws in wb.worksheets:
            rows = []
            for idx, row in enumerate(ws.iter_rows(values_only=True)):
                rows.append([("" if cell is None else str(cell)) for cell in row])
                if idx + 1 >= limit_rows:
                    break
            blocks.append(f"## Sheet: {ws.title}\n{rows_to_markdown(rows)}")
        return {"text": "\n\n".join(blocks), "engine": "openpyxl", "error": None}
    except Exception as exc:
        return {"text": "", "engine": None, "error": f"xlsx_read_failed:{exc}"}


def read_zip(path: Path):
    result = {"files": [], "text_blocks": [], "error": None}
    try:
        with zipfile.ZipFile(path, "r") as zf:
            names = zf.namelist()
            result["files"] = names
            for name in names[:200]:
                suffix = Path(name).suffix.lower()
                if suffix not in {".txt", ".md", ".csv", ".json"}:
                    continue
                try:
                    raw = zf.read(name)
                    content = ""
                    for enc in ENCODINGS:
                        try:
                            content = raw.decode(enc)
                            break
                        except Exception:
                            continue
                    if not content:
                        content = raw.decode("latin-1", errors="replace")
                    result["text_blocks"].append(f"## {name}\n{content[:6000]}")
                except Exception:
                    continue
    except Exception as exc:
        result["error"] = f"zip_read_failed:{exc}"
    return result


def parse_file(path: Path):
    suffix = path.suffix.lower()
    if suffix in {".md", ".txt", ".json"}:
        text, encoding, err = read_text_with_fallback(path)
        return {"kind": "file", "source": str(path), "text": text, "encoding": encoding, "error": err}
    if suffix == ".csv":
        csv_result = read_csv_file(path)
        if csv_result["error"]:
            return {"kind": "file", "source": str(path), "text": "", "encoding": None, "error": csv_result["error"]}
        return {
            "kind": "file",
            "source": str(path),
            "text": rows_to_markdown(csv_result["rows"]),
            "encoding": csv_result["encoding"],
            "error": None,
        }
    if suffix == ".docx":
        docx_result = read_docx(path)
        return {
            "kind": "file",
            "source": str(path),
            "text": docx_result["text"],
            "encoding": "utf-8",
            "engine": docx_result.get("engine"),
            "error": docx_result.get("error"),
        }
    if suffix == ".pdf":
        pdf_result = read_pdf(path)
        return {
            "kind": "file",
            "source": str(path),
            "text": pdf_result["text"],
            "encoding": "utf-8",
            "engine": pdf_result.get("engine"),
            "error": pdf_result.get("error"),
        }
    if suffix == ".xlsx":
        xlsx_result = read_xlsx(path)
        return {
            "kind": "file",
            "source": str(path),
            "text": xlsx_result["text"],
            "encoding": "utf-8",
            "engine": xlsx_result.get("engine"),
            "error": xlsx_result.get("error"),
        }
    if suffix == ".zip":
        zip_result = read_zip(path)
        return {
            "kind": "file",
            "source": str(path),
            "text": "\n\n".join(zip_result["text_blocks"]),
            "encoding": "utf-8",
            "files": zip_result["files"],
            "error": zip_result["error"],
        }
    return {"kind": "file", "source": str(path), "text": "", "encoding": None, "error": f"unsupported:{suffix}"}


def iter_inputs(target: str):
    parsed = urlparse(target)
    if parsed.scheme in {"http", "https"}:
        yield {"mode": "url", "value": target}
        return
    path = Path(target)
    if path.is_file():
        yield {"mode": "file", "value": path}
        return
    if path.is_dir():
        for item in path.rglob("*"):
            if item.is_file():
                yield {"mode": "file", "value": item}
        return
    raise FileNotFoundError(target)


def write_markdown_report(items, output_file: Path, max_chars: int):
    lines = ["# Document Ingestion Report", ""]
    for idx, item in enumerate(items, start=1):
        source = item.get("source", "")
        lines.append(f"## Item {idx}: {source}")
        meta = {
            "kind": item.get("kind"),
            "encoding": item.get("encoding"),
            "engine": item.get("engine"),
            "error": item.get("error"),
        }
        if "files" in item:
            meta["zip_files"] = len(item.get("files", []))
        lines.append("```json")
        lines.append(json.dumps(meta, ensure_ascii=False, indent=2))
        lines.append("```")
        content = item.get("text", "") or ""
        if len(content) > max_chars:
            content = content[:max_chars] + "\n\n[TRUNCATED]"
        lines.append(content if content else "[NO CONTENT]")
        lines.append("")
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="File path, directory path, or URL")
    parser.add_argument("--output", default="outputs", help="Output directory")
    parser.add_argument("--max-chars", type=int, default=24000, help="Max chars per item in report")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "document-parse-report.md"

    results = []
    for item in iter_inputs(args.input):
        if item["mode"] == "url":
            try:
                results.append(read_url(item["value"]))
            except Exception as exc:
                results.append({"kind": "url", "source": item["value"], "text": "", "encoding": None, "error": str(exc)})
        else:
            path = item["value"]
            try:
                results.append(parse_file(path))
            except Exception as exc:
                results.append({"kind": "file", "source": str(path), "text": "", "encoding": None, "error": str(exc)})

    write_markdown_report(results, report_path, args.max_chars)
    print(str(report_path))


if __name__ == "__main__":
    main()
