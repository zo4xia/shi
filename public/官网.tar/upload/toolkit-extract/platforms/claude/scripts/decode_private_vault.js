#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i++) {
    const token = argv[i];
    if (token.startsWith("--")) {
      const key = token.slice(2);
      const val = argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[++i] : true;
      args[key] = val;
    }
  }
  return args;
}

function ensureDir(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function main() {
  const args = parseArgs(process.argv);
  const vaultPath = args.vault || "vault/private-content.b64.json";
  const outDir = args.out || ".private-decoded";

  if (!fs.existsSync(vaultPath)) {
    console.error(`[vault] not found: ${vaultPath}`);
    process.exit(1);
  }
  const payload = JSON.parse(fs.readFileSync(vaultPath, "utf8"));
  const files = payload.files || {};
  let count = 0;
  for (const [rel, b64] of Object.entries(files)) {
    const outPath = path.join(outDir, rel);
    ensureDir(outPath);
    fs.writeFileSync(outPath, Buffer.from(b64, "base64"));
    count += 1;
  }
  console.log(`[vault] decoded files: ${count}`);
  console.log(`[vault] output: ${path.resolve(outDir)}`);
}

main();
