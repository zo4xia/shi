#!/usr/bin/env python3
import argparse
import base64
import json
import subprocess
import sys
import zipfile
from pathlib import Path


def run_python(script: Path, args: list[str], cwd: Path):
    cmd = [sys.executable, str(script)] + args
    subprocess.run(cmd, check=True, cwd=str(cwd))


def load_public_rules(source: Path):
    rules_path = source / "scripts" / "public_pack_rules.json"
    if not rules_path.exists():
        return {"sensitive_relative_paths": [], "sensitive_prefixes": []}
    return json.loads(rules_path.read_text(encoding="utf-8"))


def is_sensitive(relative_posix: str, rules: dict):
    if relative_posix in set(rules.get("sensitive_relative_paths", [])):
        return True
    for prefix in rules.get("sensitive_prefixes", []):
        if relative_posix.startswith(prefix):
            return True
    return False


def add_path_to_zip(
    zipf: zipfile.ZipFile,
    source: Path,
    arc_prefix: str,
    exclude_prefixes=None,
    rules=None,
    private_mode="b64",
    private_bucket=None,
):
    exclude_prefixes = exclude_prefixes or []
    rules = rules or {"sensitive_relative_paths": [], "sensitive_prefixes": []}
    private_bucket = private_bucket if private_bucket is not None else {}

    if source.is_file():
        zipf.write(source, arcname=f"{arc_prefix}/{source.name}")
        return

    for file_path in source.rglob("*"):
        if file_path.is_file():
            relative = file_path.relative_to(source).as_posix()
            if any(relative.startswith(prefix) for prefix in exclude_prefixes):
                continue
            if is_sensitive(relative, rules):
                if private_mode == "b64":
                    private_bucket[relative] = base64.b64encode(file_path.read_bytes()).decode("ascii")
                continue
            zipf.write(file_path, arcname=f"{arc_prefix}/{relative}")


def create_release_readme_js(name: str):
    return (
        "#!/usr/bin/env node\n"
        f"console.log('{name} - UNIVERSAL RELEASE');\n"
        "console.log('This package is offline-ready and cross-platform.');\n"
        "console.log('Included: skill/ and platforms/');\n"
        "console.log('Startup: node skill/readme.js --quick');\n"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=".", help="Skill root directory")
    parser.add_argument("--name", default="XIA'S-AI短剧制作工具箱V1", help="Release package base name")
    parser.add_argument("--output-dir", default=".", help="Where to write final zip")
    parser.add_argument(
        "--private-mode",
        default="b64",
        choices=["b64", "strip"],
        help="How to handle sensitive files in release: b64 (hide but keep), strip (remove)",
    )
    args = parser.parse_args()

    source = Path(args.source).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    scripts_dir = source / "scripts"
    convert_script = scripts_dir / "convert_multi_platform.py"
    utf8_script = scripts_dir / "utf8_guard.py"
    platforms_dir = source / "dist" / "platforms"
    rules = load_public_rules(source)

    # 1) Generate platform conversion (without duplicated bundled resources)
    run_python(convert_script, ["--source", str(source), "--output", str(platforms_dir)], cwd=source)

    # 2) UTF-8 guard for source and generated outputs
    run_python(utf8_script, ["--path", str(source), "--fix"], cwd=source)
    run_python(utf8_script, ["--path", str(platforms_dir), "--fix"], cwd=source)

    # 3) One universal zip
    zip_name = f"{args.name}-UNIVERSAL.zip"
    zip_path = output_dir / zip_name
    if zip_path.exists():
        zip_path.unlink()

    private_bucket = {}
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        add_path_to_zip(
            zipf,
            source,
            "skill",
            exclude_prefixes=[
                "dist/",
                "__pycache__/",
                ".git/",
            ],
            rules=rules,
            private_mode=args.private_mode,
            private_bucket=private_bucket,
        )
        add_path_to_zip(zipf, platforms_dir, "platforms")
        if args.private_mode == "b64" and private_bucket:
            vault_payload = {
                "encoding": "base64",
                "count": len(private_bucket),
                "files": private_bucket,
            }
            zipf.writestr(
                "skill/vault/private-content.b64.json",
                json.dumps(vault_payload, ensure_ascii=False, indent=2).encode("utf-8"),
            )
        zipf.writestr("readme.js", create_release_readme_js(args.name).encode("utf-8"))
        summary = {
            "name": args.name,
            "source": str(source),
            "platforms_dir": str(platforms_dir),
            "zip": str(zip_path),
            "encoding": "utf-8",
            "private_mode": args.private_mode,
            "private_files_hidden": len(private_bucket),
        }
        zipf.writestr("release-summary.json", json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8"))

    print(str(zip_path))


if __name__ == "__main__":
    main()
