#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 2; i < argv.length; i++) {
    const token = argv[i];
    if (token.startsWith("--")) {
      const key = token.slice(2);
      const next = argv[i + 1];
      if (!next || next.startsWith("--")) {
        args[key] = true;
      } else {
        args[key] = next;
        i += 1;
      }
    } else {
      args._.push(token);
    }
  }
  return args;
}

function ensureDir(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, data) {
  ensureDir(filePath);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

function writeText(filePath, text) {
  ensureDir(filePath);
  fs.writeFileSync(filePath, text, "utf8");
}

const ROUTE_KEYWORDS = {
  mode_client_issue: [
    "打不开", "乱码", "utf8", "编码", "报错", "不兼容", "导出zip", "导出md", "pdf", "docx", "大文件"
  ],
  mode_rejection: [
    "甲方驳回", "被打回", "驳回", "客户不满意", "返工", "不过审"
  ],
  mode_evaluation: [
    "评估", "打分", "能不能做", "商业化", "可行性"
  ],
  type2: [
    "没有稿子", "从零", "我想创作", "帮我写", "构思", "灵感"
  ],
  type3: [
    "我有稿子", "我有剧本", "按这个稿子", "帮我拆分镜", "已有文稿"
  ]
};

function hitCount(text, words) {
  const lower = text.toLowerCase();
  return words.reduce((acc, w) => acc + (lower.includes(w.toLowerCase()) ? 1 : 0), 0);
}

function routeText(text) {
  const scores = {};
  Object.keys(ROUTE_KEYWORDS).forEach((k) => {
    scores[k] = hitCount(text, ROUTE_KEYWORDS[k]);
  });

  let mode = "mode_evaluation";
  if (scores.mode_client_issue >= Math.max(scores.mode_rejection, scores.mode_evaluation)) {
    mode = "mode_client_issue";
  } else if (scores.mode_rejection > scores.mode_evaluation) {
    mode = "mode_rejection";
  }

  let userType = "type2";
  if (scores.type3 > scores.type2) userType = "type3";

  return {
    mode,
    user_type: userType,
    scores,
    timestamp: new Date().toISOString()
  };
}

const WEIGHTS = {
  type2: {
    market_hook: 20,
    shootable_structure: 20,
    ai_generation_fitness: 20,
    continuity_control: 15,
    cost_duration_execution: 15,
    copy_paste_readiness: 10
  },
  type3: {
    source_decomposability: 15,
    storyboard_timing_precision: 25,
    asset_mapping_completeness: 20,
    platform_execution_readiness: 20,
    continuity_rework_mechanism: 10,
    handoff_independence: 10
  }
};

function evaluate(type, payload) {
  if (!WEIGHTS[type]) throw new Error(`unsupported type: ${type}`);
  const weights = WEIGHTS[type];
  const scores = payload.scores || {};
  let total = 0;
  const details = [];

  for (const [dim, weight] of Object.entries(weights)) {
    const raw = Number(scores[dim] ?? 0);
    const bounded = Math.max(0, Math.min(5, raw));
    const weighted = (bounded / 5) * weight;
    total += weighted;
    details.push({ dimension: dim, raw: bounded, weight, weighted: Number(weighted.toFixed(2)) });
  }

  total = Number(total.toFixed(2));
  let verdict = "reject";
  if (total >= 85) verdict = "pass";
  else if (total >= 70) verdict = "repair_required";

  const weakest = [...details].sort((a, b) => a.raw - b.raw).slice(0, 3).map((d) => d.dimension);
  return {
    type,
    total,
    verdict,
    threshold: { pass: ">=85", repair_required: "70-84", reject: "<70" },
    details,
    weakest_dimensions: weakest,
    timestamp: new Date().toISOString()
  };
}

function runVeto(payload) {
  const items = payload.items || {};
  const failed = Object.entries(items).filter(([, ok]) => ok === false).map(([k]) => k);
  return {
    pass: failed.length === 0,
    failed_items: failed,
    failed_count: failed.length,
    timestamp: new Date().toISOString()
  };
}

const FORBIDDEN_PATTERNS = [
  /<tool_call_block>/i,
  /<tool_result_block>/i,
  /<tool_call/i,
  /<tool_result/i,
  /\bRead<\/tool_name>/i,
  /\/opt\/uclaw/i,
  /C:\\/i,
  /D:\\/i,
  /thinking/i
];

function sanitizeOutput(text, strict) {
  const lines = text.split(/\r?\n/);
  const leaked = [];
  const kept = [];
  for (const line of lines) {
    const hit = FORBIDDEN_PATTERNS.find((p) => p.test(line));
    if (hit) leaked.push({ line, pattern: String(hit) });
    else kept.push(line);
  }
  if (strict && leaked.length > 0) {
    return { ok: false, leaked, text: "" };
  }
  return { ok: true, leaked, text: kept.join("\n").trim() };
}

function renderEvaluation(result) {
  const lines = [];
  lines.push("# 评估结论");
  lines.push("");
  lines.push(`- 类型：${result.type}`);
  lines.push(`- 总分：${result.total}/100`);
  lines.push(`- 结论：${result.verdict}`);
  lines.push("");
  lines.push("## 维度明细");
  result.details.forEach((d) => {
    lines.push(`- ${d.dimension}: raw=${d.raw}/5, weighted=${d.weighted}/${d.weight}`);
  });
  lines.push("");
  lines.push("## 优先修复");
  result.weakest_dimensions.forEach((d, i) => lines.push(`${i + 1}. ${d}`));
  return lines.join("\n");
}

function printHelp() {
  console.log(`core_engine.js
Commands:
  route --text "..." [--output route.json]
  evaluate --type type2|type3 --input input.json [--output result.json]
  veto --input veto.json [--output veto-result.json]
  sanitize --input draft.txt [--output safe.txt] [--strict]
  render --kind evaluation --input result.json [--output result.md]
`);
}

function main() {
  const args = parseArgs(process.argv);
  const cmd = args._[0];
  if (!cmd) return printHelp();

  if (cmd === "route") {
    const text = args.text || "";
    const result = routeText(text);
    if (args.output) writeJson(args.output, result);
    else console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (cmd === "evaluate") {
    const type = args.type;
    if (!type) throw new Error("missing --type");
    const payload = readJson(args.input);
    const result = evaluate(type, payload);
    if (args.output) writeJson(args.output, result);
    else console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (cmd === "veto") {
    const payload = readJson(args.input);
    const result = runVeto(payload);
    if (args.output) writeJson(args.output, result);
    else console.log(JSON.stringify(result, null, 2));
    return;
  }

  if (cmd === "sanitize") {
    const text = fs.readFileSync(args.input, "utf8");
    const result = sanitizeOutput(text, Boolean(args.strict));
    if (!result.ok) {
      console.error(JSON.stringify({ error: "leak_detected", leaked: result.leaked }, null, 2));
      process.exit(2);
    }
    if (args.output) writeText(args.output, result.text);
    else console.log(result.text);
    return;
  }

  if (cmd === "render") {
    const kind = args.kind || "evaluation";
    const input = readJson(args.input);
    let text = "";
    if (kind === "evaluation") text = renderEvaluation(input);
    else throw new Error(`unsupported render kind: ${kind}`);
    if (args.output) writeText(args.output, text);
    else console.log(text);
    return;
  }

  printHelp();
}

try {
  main();
} catch (error) {
  console.error(`[core_engine] ${error.message}`);
  process.exit(1);
}
