#!/usr/bin/env python3
import argparse
from pathlib import Path


TEXT_EXTS = {".md", ".txt", ".json", ".yaml", ".yml", ".py", ".csv"}
ENCODINGS = ["utf-8", "utf-8-sig", "gbk", "gb18030", "utf-16", "latin-1"]


def detect_and_decode(raw: bytes):
    for encoding in ENCODINGS:
        try:
            return raw.decode(encoding), encoding, None
        except Exception:
            continue
    return raw.decode("latin-1", errors="replace"), "latin-1-replace", "fallback_replace"


def iter_text_files(root: Path):
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() in TEXT_EXTS:
            yield p


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default=".", help="Scan root path")
    parser.add_argument("--fix", action="store_true", help="Rewrite detected text files to UTF-8")
    args = parser.parse_args()

    root = Path(args.path).resolve()
    total = 0
    converted = 0
    issues = []

    for file_path in iter_text_files(root):
        total += 1
        raw = file_path.read_bytes()
        text, enc, err = detect_and_decode(raw)
        if enc != "utf-8":
            issues.append((file_path, enc, err))
            if args.fix:
                file_path.write_text(text, encoding="utf-8", newline="\n")
                converted += 1

    report = root / "utf8-guard-report.txt"
    lines = [
        f"root={root}",
        f"total_text_files={total}",
        f"non_utf8_found={len(issues)}",
        f"converted={converted}",
        "",
    ]
    for p, enc, err in issues:
        lines.append(f"{p} | detected={enc} | note={err or 'ok'}")
    report.write_text("\n".join(lines), encoding="utf-8")

    print(str(report))
    print(f"total={total} non_utf8={len(issues)} converted={converted}")


if __name__ == "__main__":
    main()
