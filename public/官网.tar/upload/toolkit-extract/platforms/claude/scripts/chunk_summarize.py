#!/usr/bin/env python3
import argparse
import re
from pathlib import Path


ENCODINGS = ["utf-8", "utf-8-sig", "gbk", "gb18030", "utf-16", "latin-1"]
KEYWORDS = ["风险", "问题", "异常", "失败", "修复", "必须", "禁止", "交付", "时间", "成本", "quality", "error", "fail"]


def read_text(path: Path):
    raw = path.read_bytes()
    for encoding in ENCODINGS:
        try:
            return raw.decode(encoding), encoding
        except Exception:
            pass
    return raw.decode("latin-1", errors="replace"), "latin-1-replace"


def split_chunks(text: str, chunk_size: int, overlap: int):
    chunks = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + chunk_size, length)
        chunks.append(text[start:end])
        if end >= length:
            break
        start = max(0, end - overlap)
    return chunks


def extract_key_lines(chunk: str, limit=8):
    lines = [line.strip() for line in chunk.splitlines() if line.strip()]
    selected = []
    for line in lines:
        lower = line.lower()
        if any(k in line or k in lower for k in KEYWORDS):
            selected.append(line)
        if len(selected) >= limit:
            break
    if not selected:
        selected = lines[: min(limit, len(lines))]
    return selected


def short_summary(chunk: str, max_len=360):
    content = re.sub(r"\s+", " ", chunk).strip()
    if len(content) <= max_len:
        return content
    return content[:max_len] + "..."


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Input text/markdown file")
    parser.add_argument("--output", required=True, help="Output markdown path")
    parser.add_argument("--chunk-size", type=int, default=6000)
    parser.add_argument("--overlap", type=int, default=400)
    args = parser.parse_args()

    text, encoding = read_text(Path(args.input))
    chunks = split_chunks(text, args.chunk_size, args.overlap)

    lines = []
    lines.append("# Large File Chunk Summary")
    lines.append("")
    lines.append(f"- source: `{args.input}`")
    lines.append(f"- encoding: `{encoding}`")
    lines.append(f"- chunk_count: `{len(chunks)}`")
    lines.append("")

    for idx, chunk in enumerate(chunks, start=1):
        lines.append(f"## Chunk {idx}")
        lines.append("")
        lines.append("### Snapshot")
        lines.append(short_summary(chunk))
        lines.append("")
        lines.append("### Key Points")
        for point in extract_key_lines(chunk):
            lines.append(f"- {point}")
        lines.append("")

    lines.append("## Global Notes")
    lines.append("- 逐块结论如有冲突，需回源复核原文。")
    lines.append("- 本文件为结构化摘要，不替代原文审阅。")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    print(str(output))


if __name__ == "__main__":
    main()
