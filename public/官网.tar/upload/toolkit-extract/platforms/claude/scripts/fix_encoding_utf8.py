#!/usr/bin/env python3
import argparse
from pathlib import Path


ENCODINGS = ["utf-8", "utf-8-sig", "gbk", "gb18030", "utf-16", "latin-1"]


def decode_with_fallback(raw: bytes):
    for encoding in ENCODINGS:
        try:
            return raw.decode(encoding), encoding
        except Exception:
            continue
    return raw.decode("latin-1", errors="replace"), "latin-1-replace"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Input text-like file")
    parser.add_argument("--output", required=True, help="Output UTF-8 file path")
    args = parser.parse_args()

    src = Path(args.input)
    dst = Path(args.output)
    raw = src.read_bytes()
    text, detected = decode_with_fallback(raw)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(text, encoding="utf-8")
    log_path = dst.with_suffix(dst.suffix + ".encoding.log.txt")
    log_path.write_text(
        f"source={src}\noutput={dst}\ndetected={detected}\nwritten=utf-8\n",
        encoding="utf-8",
    )
    print(str(dst))
    print(str(log_path))


if __name__ == "__main__":
    main()
