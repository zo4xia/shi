#!/usr/bin/env python3
import argparse
import shutil
import zipfile
from pathlib import Path


TEXT_EXTS = {".md", ".txt", ".csv", ".json"}


def build_md_from_path(source: Path):
    lines = [f"# Export from {source}", ""]
    if source.is_file():
        lines.extend(read_file_block(source))
        return "\n".join(lines)
    for file in sorted(source.rglob("*")):
        if not file.is_file():
            continue
        if file.suffix.lower() in TEXT_EXTS:
            lines.extend(read_file_block(file))
    return "\n".join(lines)


def read_file_block(path: Path):
    for enc in ["utf-8", "utf-8-sig", "gbk", "gb18030", "utf-16", "latin-1"]:
        try:
            content = path.read_text(encoding=enc)
            break
        except Exception:
            content = None
    if content is None:
        content = "[BINARY OR UNREADABLE]"
    return [f"## {path}", "", "```", content[:24000], "```", ""]


def zip_path(source: Path, out_zip: Path):
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    if source.is_file():
        with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(source, arcname=source.name)
        return
    shutil.make_archive(str(out_zip.with_suffix("")), "zip", root_dir=str(source))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, help="File or directory to export")
    parser.add_argument("--zip", help="Zip output path")
    parser.add_argument("--md", help="Markdown output path")
    args = parser.parse_args()

    source = Path(args.source)
    if not source.exists():
        raise FileNotFoundError(source)

    if args.zip:
        zip_path(source, Path(args.zip))
        print(Path(args.zip))
    if args.md:
        md_path = Path(args.md)
        md_path.parent.mkdir(parents=True, exist_ok=True)
        md_path.write_text(build_md_from_path(source), encoding="utf-8")
        print(md_path)


if __name__ == "__main__":
    main()
