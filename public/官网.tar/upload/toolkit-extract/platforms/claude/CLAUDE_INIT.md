Read `SKILL.md` first. Use type routing and actionable outputs only.
