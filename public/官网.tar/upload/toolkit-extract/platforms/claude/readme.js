#!/usr/bin/env node

function help() {
  return `
XIA'S-AI短剧制作工具箱V1

用法：
  node readme.js
  node readme.js --quick
  node readme.js --build

说明：
  - 本入口仅输出对用户可见的公开使用指引
  - 内部规则、内部流程不会在这里展示
`.trim();
}

function quickGuide() {
  return `
快速开始（公开版）
1) 先做路由判型（类型2/类型3）
2) 再做评分与否决检查
3) 输出模板化结论
4) 发布前执行 UTF-8 检测
`.trim();
}

function buildGuide() {
  return `
一键发布（公开版）
  python scripts/build_universal_release.py --source . --name "XIA'S-AI短剧制作工具箱V1"

跨平台初始化
  python scripts/convert_multi_platform.py --source . --output dist/platforms
`.trim();
}

const args = process.argv.slice(2);
if (args.includes("--quick")) {
  console.log(quickGuide());
} else if (args.includes("--build")) {
  console.log(buildGuide());
} else {
  console.log(help());
}
