# 跨平台兼容规则（Claude / Qwen / OpenAI / Gemini / OpenClaw）

## 设计原则

- 使用统一元数据源：`compatibility/universal-skill-manifest.json`
- 平台差异通过初始化转换脚本生成，不手工维护多份主文档
- 所有生成文件强制 UTF-8 编码

## 平台初始化差异（摘要）

| 平台 | 主入口文件 | 兼容要点 |
|---|---|---|
| Claude | `SKILL.md` | 保留 frontmatter 与主体说明 |
| Qwen | `SKILL.md` + `QWEN_INIT.md` | 增加简化初始化入口，强调中文执行口径 |
| OpenAI | `SKILL.md` + `agents/openai.yaml` | 生成 UI 元数据，便于技能展示/触发 |
| Gemini | `GEMINI.md` | 生成 Gemini 风格初始化指令 |
| OpenClaw | `SKILL.md` + `openclaw.init.json` | 生成 OpenClaw 初始化映射 |

## 转换命令

```bash
python scripts/convert_multi_platform.py --source . --output dist/platforms
```

> Windows 长路径环境下，建议默认不复制超大素材目录。  
> 如确需复制，追加 `--include-bundled` 并使用较短输出路径（例如 `--output .\\dist\\p`）。

## 编码要求

- 初始化转换输出必须 UTF-8
- 若平台导入出现乱码，先执行：

```bash
python scripts/utf8_guard.py --path dist/platforms --fix
```

## 发布建议

1. 先运行平台初始化转换
2. 再运行 UTF-8 检测/修复
3. 最后打包 `dist/platforms` 给客户

## 一键发布（推荐）

```bash
python scripts/build_universal_release.py --source . --name "XIA'S-AI短剧制作工具箱V1"
```

该命令会自动完成：转换 + UTF-8守护 + 单一通用离线包输出。
