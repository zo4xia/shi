# Runtime JS Playbook（核心流程脚本化）

> 目标：核心流程用脚本执行，`md` 仅做规则解释，减少泄露和跑偏。

## 1) 路由判型

```bash
node scripts/core_engine.js route --text "用户原话" --output outputs/route.json
```

## 2) 类型评分

```bash
# 类型2
node scripts/core_engine.js evaluate --type type2 --input templates/runtime-input-type2.json --output outputs/eval-type2.json

# 类型3
node scripts/core_engine.js evaluate --type type3 --input templates/runtime-input-type3.json --output outputs/eval-type3.json
```

## 3) 一票否决

```bash
node scripts/core_engine.js veto --input templates/runtime-veto-input.json --output outputs/veto.json
```

## 4) 防泄露输出闸门（发送前必须过）

```bash
node scripts/core_engine.js sanitize --input draft.txt --output safe.txt --strict
```

> `--strict` 模式命中泄露模式会直接失败并阻断输出。

## 5) 结果渲染

```bash
node scripts/core_engine.js render --kind evaluation --input outputs/eval-type2.json --output outputs/evaluation.md
```

## 6) UTF-8守护

```bash
python scripts/utf8_guard.py --path . --fix
```
