#!/usr/bin/env node
console.log('Target Package: openai');
console.log('Generated from universal manifest.');
console.log('Encoding: UTF-8');
console.log('Bundled resources copied: no');
