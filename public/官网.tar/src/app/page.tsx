'use client'

import { motion } from 'framer-motion'
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion'
import { MermaidDiagram } from '@/components/mermaid-diagram'
import {
  Shield,
  GitBranch,
  FileCheck,
  Lock,
  Terminal,
  Sparkles,
  Zap,
  BookOpen,
  Target,
  Layers,
  Wrench,
  Rocket,
  DollarSign,
  Users,
  Megaphone,
  Scale,
  Settings,
  HeartHandshake,
  BarChart3,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCcw,
  ClipboardList,
  Search,
  Package,
  Globe,
  Server,
  ChevronRight,
  Heart,
  Brain,
  Clock,
  TrendingUp,
  Wallet,
  Timer,
  MessageSquare,
  Hash,
  Database,
  FileText,
} from 'lucide-react'

/* ================================================================
   ANIMATION VARIANTS
   ================================================================ */
const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.5, ease: 'easeOut' },
  }),
}

const staggerContainer = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.06 } },
}

/* ================================================================
   MERMAID CHART (file names masked)
   ================================================================ */
const workflowChart = `graph TD
    A["👤 用户输入"] --> B{"🎯 路由判型<br/>cor****.js route"}
    B -->|"只有想法/关键词"| C["类型2: 无稿作者<br/>从零创作"]
    B -->|"已有剧本/文稿"| D["类型3: 有稿作者<br/>稿子转分镜"]
    B -->|"被打回/驳回"| E["模式B: 驳回诊断"]
    B -->|"打不开/乱码/报错"| F["模式C: 问题诊断"]
    
    C --> G["📝 6维评分<br/>市场钩子20% | 可拍性20%<br/>AI友好度20% | 连续性15%<br/>成本15% | 交付成熟度10%"]
    D --> H["📝 6维评分<br/>可拆解性15% | 时序精度25%<br/>素材映射20% | 执行可用度20%<br/>返工机制10% | 独立性10%"]
    
    G --> I{"⚠️ 一票否决检查<br/>cor****.js veto"}
    H --> I
    
    I -->|"✅ 无否决 + ≥85分"| J["进入生成阶段"]
    I -->|"⚠️ 70-84分"| K["🔧 输出修复工单<br/>rep***************"]
    I -->|"❌ <70分 或否决命中"| L["禁止生成，先重构"]
    
    K --> M["🔄 复评闭环"]
    M --> I
    
    J --> N["📦 标准交付结构"]
    N --> N1["01_场景执行稿"]
    N --> N2["02_专业制作版"]
    N --> N3["03_分镜执行版"]
    N --> N4["04_AI生成执行版"]
    N4 --> N5["part01~03 六件套<br/>时序分镜+素材清单<br/>Seed_Seedance复制版<br/>Gemini复制版+自检"]
    
    N5 --> P["✅ 上线验收<br/>go-**************"]
    P --> Q["📋 交付转发<br/>del************"]
    
    E --> R["🔍 驳回原因图谱<br/>6大一级原因"]
    R --> S["根因-证据-影响-修复"]
    
    F --> T["🔍 环境诊断<br/>三档兼容策略"]
    T --> U["🛠️ 降级/替代方案"]`

/* ================================================================
   NAV LINKS
   ================================================================ */
const navLinks = [
  { label: '能力总览', href: '#capabilities' },
  { label: '小红书', href: '#xhs-marketing' },
  { label: '工作流程', href: '#workflow' },
  { label: '评分体系', href: '#scoring' },
  { label: '激活指南', href: '#activation' },
  { label: '创业技能', href: '#startup-skills' },
]

/* ================================================================
   STATS DATA
   ================================================================ */
const heroStats = [
  { label: '版本', value: 'v4.4.0' },
  { label: '兼容平台', value: '5 个 AI 平台' },
  { label: '内置文件', value: '26 个 (17 refs + 9 templates)' },
  { label: '自动化脚本', value: '10 个 (Python + Node.js)' },
]

/* ================================================================
   SCORING TABLE DATA
   ================================================================ */
const scoringType2 = [
  { dim: '市场与钩子强度', weight: '20%', desc: '是否有3秒钩子、30秒翻转、结尾追更引导，目标受众是否可描述' },
  { dim: '剧情骨架可拍性', weight: '20%', desc: '是否可拆为场景→镜头→动作，是否有开端-发展-高潮-结尾' },
  { dim: 'AI可生成友好度', weight: '20%', desc: '角色/场景/动作是否可被AI准确理解生成，是否需大量negative控制' },
  { dim: '连续性可控性', weight: '15%', desc: '角色数量是否精简(≤4主角)，锚点特征是否可固定，漂移风险' },
  { dim: '成本与时长可执行性', weight: '15%', desc: '单集时长是否合理(1-5分钟)，分段是否清晰，单段是否在模型范围(5-10秒)' },
  { dim: '复制粘贴交付成熟度', weight: '10%', desc: '想法是否足够具体可直接进入脚本写作，是否有明确风格参考' },
]

const scoringType3 = [
  { dim: '原稿可拆解性', weight: '15%', desc: '原稿能否无歧义拆成镜头事件' },
  { dim: '分镜时序精度', weight: '25%', desc: '时间码、镜号、转场是否严格闭环' },
  { dim: '素材映射完整度', weight: '20%', desc: '角色/场景/道具是否一一对应可上传' },
  { dim: '平台执行可用度', weight: '20%', desc: 'Seed/Seedance/Gemini 参数是否可直接复制执行' },
  { dim: '连续性与返工机制', weight: '10%', desc: '漂移检查和返工指令是否明确' },
  { dim: '转发交付独立性', weight: '10%', desc: '不看聊天记录也能独立执行' },
]

/* ================================================================
   REJECTION DIAGNOSIS DATA
   ================================================================ */
const rejectionCauses = [
  { cause: '内容不对标', root: '题材不匹配受众', signal: '"方向不对"', impact: '点击率低、投放浪费' },
  { cause: '剧情不可拍', root: '文案强但镜头弱', signal: '"落不了地"', impact: '拍摄/生成成本暴涨' },
  { cause: '视觉不稳定', root: '角色/场景漂移', signal: '"像不同项目"', impact: '品牌资产受损' },
  { cause: '节奏失控', root: '时序与镜长失衡', signal: '"拖/乱/不抓人"', impact: '完播率下降' },
  { cause: '交付不可执行', root: '文件缺失/格式混乱', signal: '"无法直接跑"', impact: '外包执行失败' },
  { cause: '合规风险', root: '版权/肖像/平台违规', signal: '要求下线', impact: '法务风险与项目中止' },
]

/* ================================================================
   TERMINOLOGY SELF-CHECK DATA
   ================================================================ */
const terminologyReplacements = [
  { risky: '画面要高级', pro: '明确光色、景别、运镜、质感参数', check: '可逐项核对' },
  { risky: '节奏要紧张', pro: '给出时码、镜长、转场方式', check: '时序可复盘' },
  { risky: '人物要稳定', pro: '写角色锚点+漂移检查项', check: '连续性自检' },
  { risky: '按感觉调整', pro: '按修复工单逐条改动', check: '变更可追踪' },
]

/* ================================================================
   SCRIPT TOOLS DATA (file names masked)
   ================================================================ */
const scriptTools = [
  { name: 'cor****.js', lang: 'Node.js', func: '路由/评分/否决/闸门/渲染核心引擎', cmd: 'node scr***/cor****.js route --text "..."' },
  { name: 'ing****.py', lang: 'Python', func: '链接/文档/表格/压缩包解析', cmd: 'python scr***/ing****.py --input <file> --output out***/' },
  { name: 'fix****.py', lang: 'Python', func: '编码修复(统一转UTF-8)', cmd: 'python scr***/fix****.py --input <file> --output <utf8file>' },
  { name: 'chu****.py', lang: 'Python', func: '大文件分块摘要', cmd: 'python scr***/chu****.py --input <file> --output <sum****.md>' },
  { name: 'exp****.py', lang: 'Python', func: '导出ZIP与MD交付包', cmd: 'python scr***/exp****.py --source <dir> --zip <out.zip> --md <out.md>' },
  { name: 'con****.py', lang: 'Python', func: '多平台初始化转换', cmd: 'python scr***/con****.py --source . --output dis***/pla***/' },
  { name: 'utf****.py', lang: 'Python', func: '全包UTF-8检测与修复', cmd: 'python scr***/utf****.py --path . [--fix]' },
  { name: 'bui****.py', lang: 'Python', func: '一键转换+单包发布', cmd: 'python scr***/bui****.py --source . --name "..."' },
  { name: 'dec****.js', lang: 'Node.js', func: '私密base64内容解码', cmd: 'node scr***/dec****.js --vault vau***/...' },
  { name: 'pub****.json', lang: 'Config', func: '公开发布规则配置', cmd: '(配置文件)' },
]

/* ================================================================
   PLATFORM COMPATIBILITY DATA (file names masked)
   ================================================================ */
const platforms = [
  { name: 'Claude', entry: 'SKI****.md', compat: '保留frontmatter与主体说明' },
  { name: 'Qwen', entry: 'SKI****.md + QWE********', compat: '简化初始化入口，中文执行口径' },
  { name: 'OpenAI', entry: 'SKI****.md + age****/ope****.yaml', compat: 'UI元数据，技能展示/触发' },
  { name: 'Gemini', entry: 'GEM****.md', compat: 'Gemini风格初始化指令' },
  { name: 'OpenClaw', entry: 'SKI****.md + opc***************', compat: 'OpenClaw初始化映射' },
]

/* ================================================================
   ACTIVATION STEPS (commands masked)
   ================================================================ */
const activationSteps = [
  { step: 1, text: '解压工具箱到项目目录' },
  { step: 2, text: '选择目标平台（Claude / Qwen / OpenAI / Gemini / OpenClaw）' },
  { step: 3, text: '运行平台转换命令生成对应初始化文件', mono: 'python scr***/con****.py --source . --output dis***/pla***/' },
  { step: 4, text: '或一键发布通用离线包', mono: 'python scr***/bui****.py --source . --name "XIA\'S-AI短剧制作工具箱V1"' },
  { step: 5, text: '将对应平台的初始化文件配置到Agent环境中即可使用' },
]

/* ================================================================
   SKILLS DATA
   ================================================================ */
interface Skill {
  name: string
  confidence: number
  author: string
  description: string
}

interface SkillCategory {
  name: string
  icon: React.ElementType
  color: string
  skills: Skill[]
}

const skillCategories: SkillCategory[] = [
  {
    name: '融资 Fundraising',
    icon: DollarSign,
    color: 'text-emerald-700',
    skills: [
      { name: 'pitch-deck', confidence: 92, author: 'Shawn Pang', description: '创建或优化融资路演PPT，逐页叙事而非要点堆砌' },
      { name: 'investor-research', confidence: 88, author: 'Shawn Pang', description: '识别、筛选和排序潜在投资人（阶段/领域/投资规模/组合匹配）' },
      { name: 'data-room', confidence: 90, author: 'Shawn Pang', description: '准备尽调材料——清单、文档组织和缺失项草稿' },
      { name: 'fundraising-email', confidence: 85, author: 'Shawn Pang', description: '撰写投资人触达——冷启动介绍、跟进邮件和感谢信' },
      { name: 'accelerator-application', confidence: 87, author: 'Shawn Pang', description: '申请YC、Techstars等40+加速器，含目录和面试准备' },
    ],
  },
  {
    name: '销售与商务 Sales & BD',
    icon: BarChart3,
    color: 'text-blue-700',
    skills: [
      { name: 'cold-outreach', confidence: 89, author: 'Brian Wagner', description: '撰写B2B开拓邮件、LinkedIn消息和跟进序列' },
      { name: 'sales-script', confidence: 86, author: 'Alireza Rezvani', description: '演示脚本、发现会议框架、异议处理和成交策略' },
      { name: 'proposal-generation', confidence: 91, author: 'Alireza Rezvani', description: '创建销售提案、SOW和报价方案' },
      { name: 'lead-scoring', confidence: 84, author: 'Athina AI', description: '定义ICP标准、线索资格评估框架和评分模型' },
      { name: 'partnership-outreach', confidence: 87, author: 'Shawn Pang', description: '撰写合作提案、集成方案和联合营销拓展' },
    ],
  },
  {
    name: '产品与战略 Product & Strategy',
    icon: Layers,
    color: 'text-violet-700',
    skills: [
      { name: 'prd-writing', confidence: 93, author: 'Pawel Huryn', description: '撰写产品需求文档、功能规格和用户故事集' },
      { name: 'user-research-synthesis', confidence: 88, author: 'Pawel Huryn', description: '整合用户访谈、调研数据和支持工单' },
      { name: 'roadmap-planning', confidence: 90, author: 'Pawel Huryn', description: '构建产品路线图，含时间线、依赖和里程碑' },
      { name: 'mvp-scoping', confidence: 91, author: 'Shawn Pang', description: '定义MVP范围——该做什么、该砍什么、该推迟什么' },
      { name: 'competitive-analysis', confidence: 87, author: 'Pawel Huryn', description: '竞品功能对比、定位分析和定价基准' },
      { name: 'market-research', confidence: 85, author: 'Pawel Huryn', description: '市场规模测算(TAM/SAM/SOM)、趋势和假设验证' },
      { name: 'review-mining', confidence: 86, author: 'Shawn Pang', description: '挖掘Trustpilot/G2/App Store评论中的用户痛点' },
      { name: 'daily-product-digest', confidence: 83, author: 'Shawn Pang', description: '每日汇总Product Hunt和Hacker News趋势' },
      { name: 'competitor-monitoring', confidence: 88, author: 'Shawn Pang', description: '持续追踪竞品定价、功能、招聘和定位变化' },
    ],
  },
  {
    name: '招聘与团队 Recruiting & Team',
    icon: Users,
    color: 'text-cyan-700',
    skills: [
      { name: 'job-description', confidence: 90, author: 'Shawn Pang', description: '撰写吸引人的职位描述，无企业话术' },
      { name: 'interview-kit', confidence: 88, author: 'Alireza Rezvani', description: '设计面试流程——问题、评分卡和薪资对标' },
      { name: 'sourcing-outreach', confidence: 85, author: 'Shawn Pang', description: '撰写人才寻访——LinkedIn InMail和冷启动邮件' },
      { name: 'employer-brand', confidence: 83, author: 'Shawn Pang', description: '构建雇主品牌——招聘页面、团队文化和工程博客' },
    ],
  },
  {
    name: '工程 Engineering',
    icon: Settings,
    color: 'text-orange-700',
    skills: [
      { name: 'architecture-design', confidence: 92, author: 'Alireza Rezvani', description: '系统架构设计——服务边界、数据模型和API' },
      { name: 'code-review', confidence: 90, author: 'Jeff Allan', description: '代码审查聚焦正确性、安全性、性能和可维护性' },
      { name: 'cicd-setup', confidence: 87, author: 'Alireza Rezvani', description: 'CI/CD流水线——GitHub Actions、测试和部署自动化' },
      { name: 'tech-stack-eval', confidence: 86, author: 'Alireza Rezvani', description: '评估和选择技术栈——框架、数据库和托管' },
      { name: 'security-review', confidence: 89, author: 'Jeff Allan', description: '安全审计——OWASP Top 10、认证流程和依赖漏洞' },
    ],
  },
  {
    name: '法务与合规 Legal & Compliance',
    icon: Scale,
    color: 'text-yellow-700',
    skills: [
      { name: 'privacy-policy', confidence: 88, author: 'Pawel Huryn', description: '生成或更新隐私政策、Cookie政策和数据处理文档' },
      { name: 'terms-of-service', confidence: 87, author: 'Shawn Pang', description: '起草或更新服务条款和SaaS协议' },
      { name: 'contract-review', confidence: 85, author: 'Shawn Pang', description: '审查合同并标记风险——供应商/合作/客户合同' },
      { name: 'soc2-prep', confidence: 82, author: 'Alireza Rezvani', description: 'SOC 2合规准备——策略模板和控制映射' },
    ],
  },
  {
    name: '运营 Operations',
    icon: ClipboardList,
    color: 'text-teal-700',
    skills: [
      { name: 'process-docs', confidence: 89, author: 'Shawn Pang', description: '文档化流程，创建SOP和内部手册' },
      { name: 'board-update', confidence: 86, author: 'Alireza Rezvani', description: '撰写投资人更新、董事会汇报和月度/季度报告' },
    ],
  },
  {
    name: '客户成功 Customer Success',
    icon: HeartHandshake,
    color: 'text-pink-700',
    skills: [
      { name: 'onboarding-flow', confidence: 88, author: 'Manoj Bajaj', description: '设计用户引导——激活流程和Time-to-Value优化' },
      { name: 'support-docs', confidence: 90, author: 'Shawn Pang', description: '创建帮助中心、FAQ和API文档' },
      { name: 'feedback-synthesis', confidence: 85, author: 'Pawel Huryn', description: '分析客户反馈——分类主题和优先级排序' },
      { name: 'churn-analysis', confidence: 84, author: 'Athina AI', description: '分析流失——识别驱动因素和设计挽回活动' },
      { name: 'sentiment-monitoring', confidence: 83, author: 'Shawn Pang', description: '监控产品评论和公开提及，含回复草稿' },
    ],
  },
  {
    name: '营销与增长 Marketing & Growth',
    icon: Megaphone,
    color: 'text-red-700',
    skills: [
      { name: 'landing-page', confidence: 92, author: 'Corey Haines', description: '构建或优化落地页——文案、布局和转化' },
      { name: 'content-strategy', confidence: 89, author: 'Corey Haines', description: '规划内容——博客策略、SEO日历和思想领导力' },
      { name: 'seo-technical', confidence: 87, author: 'Daniel Agrici', description: '技术SEO审计——站点结构、元标签和Core Web Vitals' },
      { name: 'email-marketing', confidence: 88, author: 'Corey Haines', description: '创建邮件活动——Newsletter、Drip和生命周期邮件' },
      { name: 'social-content', confidence: 86, author: 'Brian Wagner', description: '创建社交媒体内容——LinkedIn和Twitter/X' },
      { name: 'launch-strategy', confidence: 91, author: 'Daniel Mendes', description: '产品发布规划——Product Hunt、HN和媒体推广' },
      { name: 'founder-thought-leadership', confidence: 85, author: 'Shawn Pang', description: '创始人IP和个人品牌——原创框架和公开分享' },
      { name: 'community-discovery', confidence: 83, author: 'Shawn Pang', description: '发现目标用户所在的Slack/Discord/Reddit社区' },
      { name: 'event-hosting', confidence: 84, author: 'Shawn Pang', description: '策划技术活动和Meetup——议程、嘉宾和推广' },
      { name: 'earned-media-outreach', confidence: 86, author: 'Shawn Pang', description: '找到播客、记者和Newsletter作者获取曝光' },
    ],
  },
]

const totalSkills = skillCategories.reduce((sum, c) => sum + c.skills.length, 0)

/* ================================================================
   HELPER: Confidence Badge Color
   ================================================================ */
function getConfidenceColor(confidence: number) {
  if (confidence >= 90) return 'bg-emerald-50 text-emerald-700 border-emerald-200'
  if (confidence >= 85) return 'bg-amber-50 text-amber-700 border-amber-200'
  if (confidence >= 80) return 'bg-orange-50 text-orange-700 border-orange-200'
  return 'bg-red-50 text-red-700 border-red-200'
}

/* ================================================================
   FILE TREE STRUCTURE (all names masked)
   ================================================================ */
const fileTreeLines = [
  "XIA'S-AI短剧制作工具箱V1/",
  "├── SKI****.md                        # 总规则、路由、评分、否决、阈值",
  "├── PAC****.md                        # 离线发行包清单",
  "├── rea****.js                         # 公开运行入口",
  "├── com***/",
  "│   └── uni****.json                   # 平台无关元数据",
  "├── ref***/                            # 17个参考文档",
  "│   ├── int****.md                     # 接单信息采集+路由表",
  "│   ├── typ****.md                     # 类型2无稿作者评分模板",
  "│   ├── typ****.md                     # 类型3有稿作者评分模板",
  "│   ├── one****.md                     # 一票否决清单",
  "│   ├── rep****.md                     # 70-84分修复工单",
  "│   ├── go-****.md                     # 上线验收清单",
  "│   ├── pro****.md                     # 专业术语自查",
  "│   ├── cli****.md                     # 甲方驳回原因图谱",
  "│   ├── tri****.md                     # 触发词与路由",
  "│   ├── pro****.md                     # 渐进式披露地图",
  "│   ├── run****.md                     # 环境兼容策略",
  "│   ├── uni****.md                     # 输入解析规范",
  "│   ├── enc****.md                     # 编码与大文件处理",
  "│   ├── cro****.md                     # 跨平台兼容规则",
  "│   ├── run****.md                     # 核心流程脚本化手册",
  "│   ├── cli****.md",
  "│   └── ...更多",
  "├── tem***/                            # 9个输出模板",
  "│   ├── eva****.md                     # 评估结论标准输出",
  "│   ├── del****.md                     # 交付转发模板",
  "│   ├── cli****.md",
  "│   ├── cli****.md",
  "│   ├── doc****.md",
  "│   ├── lar****.md",
  "│   ├── run****.json",
  "│   ├── run****.json",
  "│   └── run****.json",
  "├── scr***/                            # 10个自动化脚本",
  "│   ├── cor****.js                     # 核心引擎(路由/评分/否决/闸门)",
  "│   ├── ing****.py                     # 文档解析",
  "│   ├── fix****.py                     # 编码修复",
  "│   ├── chu****.py                     # 大文件摘要",
  "│   ├── exp****.py                     # 交付导出",
  "│   ├── con****.py                     # 多平台转换",
  "│   ├── utf****.py                     # UTF-8守护",
  "│   ├── bui****.py                     # 一键发布",
  "│   ├── dec****.js                     # 私密解码",
  "│   └── pub****.json                   # 发布规则",
  "├── bun***/                            # 内置源资料(离线可用)",
  "│   └── sou*******/",
  "│       ├── 术****/                     # 影视术语对照表",
  "│       ├── 单*************/             # 完整模板示例",
  "│       └── 5-*********/                # 高级版模板",
  "└── vau***/",
  "    └── pri****.json                    # 私密内容(base64)",
]

/* ================================================================
   XHS MARKETING DATA
   ================================================================ */
const xhsStats = [
  { label: '核心能力模块', value: '6 大' },
  { label: '策略规则', value: '15 条' },
  { label: '可复用模板', value: '6 个' },
  { label: '知识库文档', value: '8 个' },
  { label: '自动化脚本', value: '3 个' },
]

const xhsArchitecture = [
  { layer: 'SOUL Layer', label: '人设层', icon: Heart, color: 'bg-rose-50 border-rose-200 text-rose-600', desc: '定义Agent人格、专业领域、沟通风格和工作边界' },
  { layer: 'AGENTS Layer', label: '行为层', icon: Brain, color: 'bg-orange-50 border-orange-200 text-orange-600', desc: '定义Agent行为规则、自主级别(可自主/需确认/禁止)、记忆管理' },
  { layer: 'MEMORY Layer', label: '记忆层', icon: Database, color: 'bg-blue-50 border-blue-200 text-blue-600', desc: '运行时自动更新的运营记忆，含核心数据追踪、有效策略记录、爆款分析、选题灵感库' },
  { layer: 'HEARTBEAT Layer', label: '调度层', icon: Clock, color: 'bg-violet-50 border-violet-200 text-violet-600', desc: '自主调度规则，按早/午/晚/周划分任务，含数据复盘、热点监控、内容准备、互动管理' },
]

const xhsWorkflow = [
  { step: 1, title: '诊断账号阶段', desc: '冷启动期(0-1K粉) → 成长期(1K-1W粉) → 成熟期(1W+粉)' },
  { step: 2, title: '定位分析', desc: '赛道竞争度分析 + 目标人群画像匹配 + 人设差异化建议' },
  { step: 3, title: '策略匹配', desc: '根据阶段匹配优先级策略(定位→内容→算法→互动→增长→变现)' },
  { step: 4, title: '生成执行方案', desc: '6个模板产出可执行方案' },
  { step: 5, title: '内容日历', desc: '按阶段设定发布频率和类型轮换(干货/互动/种草/引流/商务)' },
  { step: 6, title: 'KPI目标', desc: '冷启动(月增200-500/互动率5-8%) → 成长期(月增1K-3K/8-12%) → 成熟期(月增3K-5K/10-15%)' },
]

const xhsCesData = [
  { action: '收藏', weight: '1分', note: '最核心指标，代表内容长期价值' },
  { action: '点赞', weight: '1分', note: '基础认可信号' },
  { action: '评论', weight: '4分', note: '深度互动，权重最高' },
  { action: '转发', weight: '4分', note: '社交裂变信号' },
  { action: '关注', weight: '8分', note: '最强正反馈信号' },
]

const xhsTrafficPool = [
  { level: '初始池', range: '200-500', condition: '初始分发' },
  { level: '二级池', range: '1K-5K', condition: '互动率>5%' },
  { level: '三级池', range: '1W-5W', condition: '互动率>8%' },
  { level: '热门池', range: '10W+', condition: '持续高互动' },
]

const xhsTitleFormulas = [
  '数字+关键词+利益点',
  '痛点+解决方案',
  '身份+推荐',
  '对比颠覆认知',
  '场景+效果',
  '限定+紧迫感',
]

const xhsContentRules = [
  { rule: '标题和首图决定80%流量', priority: 'CRITICAL' },
  { rule: '图片质量是第一语言', priority: 'CRITICAL' },
  { rule: '经过验证的6大标题公式', priority: 'CRITICAL' },
  { rule: '借势热点放大曝光', priority: 'HIGH' },
  { rule: '保持稳定发布节奏', priority: 'HIGH' },
]

const xhsInteractionRules = [
  { rule: '发布后1小时黄金互动期', priority: 'CRITICAL' },
  { rule: '粉丝到社群的转化路径', priority: 'HIGH' },
  { rule: '跨平台引流策略', priority: 'MEDIUM' },
]

const xhsGrowthRules = [
  { rule: '数据驱动内容迭代', priority: 'HIGH' },
  { rule: '爆款复制三方法(同主题换角度/同格式换主题/升级迭代)', priority: 'HIGH' },
  { rule: '浏览到关注的转化漏斗', priority: 'HIGH' },
  { rule: '互推合作加速破圈', priority: 'MEDIUM' },
]

const xhsMonetization = [
  { fans: '0-1K', method: '专注内容建立标签', income: '0' },
  { fans: '1K-5K', method: '好物推荐+小额合作', income: '500-3K' },
  { fans: '5K-1W', method: '品牌合作+好物推荐', income: '3K-10K' },
  { fans: '1W-5W', method: '品牌合作+知识付费', income: '1W-5W' },
  { fans: '5W-50W', method: '多元变现', income: '5W-50W' },
  { fans: '50W+', method: '全面商业化', income: '50W+' },
]

const xhsBrandPricing = [
  { type: '图文', formula: '粉×0.03-0.08' },
  { type: '视频', formula: '粉×0.05-0.12' },
  { type: '测评', formula: '粉×0.08-0.15' },
]

const xhsHeartbeatSchedule = [
  { time: '早间 (8-10点)', tasks: '数据复盘+内容规划' },
  { time: '午间 (12-13点)', tasks: '热点监控(Tavily搜索)' },
  { time: '下午 (15-17点)', tasks: '内容准备(标题+文案+标签)' },
  { time: '晚间 (20-22点)', tasks: '互动管理(评论+粉丝)' },
  { time: '周度', tasks: '周报生成+竞品扫描+策略复盘' },
]

const xhsTemplates = [
  { name: 'acc****.md', desc: '账号品牌定位简报' },
  { name: 'not****.md', desc: '笔记文案模板(5种类型: 干货/种草/经验/清单/互动)' },
  { name: 'cal****.md', desc: '月度内容日历' },
  { name: 'cmp****.md', desc: '营销活动策划' },
  { name: 'int****.md', desc: '互动运营手册' },
  { name: 'kpi****.md', desc: '增长KPI追踪' },
]

const xhsKnowledgeBase = [
  { name: 'alg****.md', desc: '推荐算法机制(CES/流量池/搜索排名)' },
  { name: 'fmt****.md', desc: '内容格式与模板规范' },
  { name: 'pos****.md', desc: '账号定位方法论' },
  { name: 'mon****.md', desc: '变现模式全景' },
  { name: 'rul****.md', desc: '平台规则与违禁词' },
  { name: 'tag****.md', desc: '话题标签策略' },
  { name: 'com****.md', desc: '竞品分析框架' },
  { name: 'aud****.md', desc: '目标用户画像' },
]

const xhsExternalTools = [
  { name: 'Tavily搜索', features: ['小红书热帖搜索', '通用搜索', '网页内容提取'] },
  { name: 'xiaohongshu-mcp', features: ['内容发布', '登录状态检查'] },
  { name: 'xiaohongshu-digest', features: ['科技热点内容抓取'] },
]

function getPriorityBadge(priority: string) {
  if (priority === 'CRITICAL') return 'bg-red-50 text-red-700 border-red-200'
  if (priority === 'HIGH') return 'bg-amber-50 text-amber-700 border-amber-200'
  return 'bg-blue-50 text-blue-700 border-blue-200'
}

/* ================================================================
   MAIN PAGE
   ================================================================ */
export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* ============================================================
          STICKY NAV BAR
          ============================================================ */}
      <nav className="sticky top-0 z-50 border-b border-gray-200 bg-white/95 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <span className="font-bold text-gray-900 tracking-tight">XIA&apos;S-AI</span>
          </div>
          <div className="hidden md:flex items-center gap-5">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm text-gray-500 hover:text-amber-600 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      </nav>

      {/* ============================================================
          SECTION 1: HERO
          ============================================================ */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-gradient-to-br from-amber-50 via-orange-50/60 to-transparent rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20">
          <motion.div
            className="text-center mb-12"
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            <motion.div variants={fadeInUp} custom={0}>
              <Badge className="mb-6 bg-amber-600 text-white border-amber-600 px-4 py-1.5 text-sm font-medium hover:bg-amber-700">
                v4.4.0
              </Badge>
            </motion.div>

            <motion.h1
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-4 text-gray-900"
              variants={fadeInUp}
              custom={1}
            >
              XIA&apos;S-AI 短剧制作工具箱
            </motion.h1>

            <motion.p
              className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto mb-3"
              variants={fadeInUp}
              custom={2}
            >
              V1 商业化短剧/漫剧生产全链路 AI Agent 技能包
            </motion.p>

            <motion.p
              className="text-base text-amber-700 font-medium max-w-xl mx-auto"
              variants={fadeInUp}
              custom={3}
            >
              从想法到交付，让AI短剧生产可评估、可执行、可复制
            </motion.p>
          </motion.div>

          {/* Stats Row */}
          <motion.div
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            {heroStats.map((stat, i) => (
              <motion.div
                key={stat.label}
                variants={fadeInUp}
                custom={i + 4}
              >
                <div className="text-center p-4 rounded-2xl border border-gray-200 bg-white shadow-sm">
                  <p className="text-2xl font-bold text-amber-600">{stat.value}</p>
                  <p className="text-xs text-gray-400 mt-1 uppercase tracking-wider font-medium">
                    {stat.label}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 2: CAPABILITIES OVERVIEW (12 Cards)
          ============================================================ */}
      <section id="capabilities" className="py-20 bg-gray-50/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">能力总览</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              12大核心能力模块，覆盖短剧制作从准入评估到交付验收的全生命周期
            </p>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-50px' }}
            variants={staggerContainer}
          >
            {/* ---- Card 1: 准入评估与双模式路由 ---- */}
            <motion.div variants={fadeInUp} custom={0}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                      <GitBranch className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">01</span>
                        <CardTitle className="text-xl font-bold text-gray-900">准入评估与双模式路由</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    工具箱的核心入口。当用户输入任意短剧/漫剧相关需求时，系统首先执行智能路由判型，将用户分为两种类型：
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-100">
                      <p className="font-semibold text-gray-900 mb-2">类型2 · 无稿作者</p>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        用户只有想法、题材、关键词，没有可拍可拆的成稿。系统先评估市场钩子强度、剧情可拍性、AI生成友好度等维度，达标后再产出可拍脚本骨架，最终生成标准执行包。
                      </p>
                    </div>
                    <div className="p-4 rounded-xl bg-orange-50/60 border border-orange-100">
                      <p className="font-semibold text-gray-900 mb-2">类型3 · 有稿作者</p>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        用户已有文稿、剧本或剧情大纲。系统重点评估原稿可拆解性、分镜时序精度、素材映射完整度，确保能稳定拆成可执行的镜头时序和平台执行稿。
                      </p>
                    </div>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-2 text-sm">路由决策逻辑</p>
                    <ul className="space-y-1.5 text-sm text-gray-600">
                      <li className="flex items-start gap-2"><ChevronRight className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />无完整剧情文本 → 类型2</li>
                      <li className="flex items-start gap-2"><ChevronRight className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />有可读文稿/剧本 → 类型3</li>
                      <li className="flex items-start gap-2"><ChevronRight className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />同时有想法和半成品 → 先按类型3评估可拆解性，不达标再回退类型2补骨架</li>
                    </ul>
                  </div>
                  <div className="p-3 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                    <span className="text-amber-400">核心命令:</span> node scr***/cor****.js route --text &quot;用户原话&quot; --output out***/rou****.json
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 2: 100分制评分体系 ---- */}
            <motion.div variants={fadeInUp} custom={1} id="scoring">
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                      <Target className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">02</span>
                        <CardTitle className="text-xl font-bold text-gray-900">100分制评分体系</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  <p className="text-gray-600 leading-relaxed">
                    采用工业级评估标准，不是&ldquo;写得好不好看&rdquo;，而是&ldquo;客户复制粘贴就能跑通并交付&rdquo;。每个维度使用0-5分制打分，再按权重换算为百分制。
                  </p>

                  {/* Type 2 Scoring Table */}
                  <div>
                    <p className="font-semibold text-gray-900 mb-3">类型2评分维度（无稿作者）</p>
                    <div className="rounded-xl border border-gray-200 overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-50">
                            <TableHead className="font-semibold text-gray-900">维度</TableHead>
                            <TableHead className="font-semibold text-gray-900 w-20 text-center">权重</TableHead>
                            <TableHead className="font-semibold text-gray-900">评估要点</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {scoringType2.map((row) => (
                            <TableRow key={row.dim}>
                              <TableCell className="font-medium text-gray-900">{row.dim}</TableCell>
                              <TableCell className="text-center">
                                <Badge className="bg-amber-50 text-amber-700 border-amber-200">{row.weight}</Badge>
                              </TableCell>
                              <TableCell className="text-gray-600 text-sm">{row.desc}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>

                  {/* Type 3 Scoring Table */}
                  <div>
                    <p className="font-semibold text-gray-900 mb-3">类型3评分维度（有稿作者）</p>
                    <div className="rounded-xl border border-gray-200 overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-50">
                            <TableHead className="font-semibold text-gray-900">维度</TableHead>
                            <TableHead className="font-semibold text-gray-900 w-20 text-center">权重</TableHead>
                            <TableHead className="font-semibold text-gray-900">评估要点</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {scoringType3.map((row) => (
                            <TableRow key={row.dim}>
                              <TableCell className="font-medium text-gray-900">{row.dim}</TableCell>
                              <TableCell className="text-center">
                                <Badge className="bg-orange-50 text-orange-700 border-orange-200">{row.weight}</Badge>
                              </TableCell>
                              <TableCell className="text-gray-600 text-sm">{row.desc}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>

                  {/* Thresholds */}
                  <div>
                    <p className="font-semibold text-gray-900 mb-3">判定阈值</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="flex items-center gap-3 p-3 rounded-xl border border-emerald-200 bg-emerald-50/50">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-semibold text-emerald-800">≥ 85分 · 通过</p>
                          <p className="text-xs text-gray-500">直接进入制作(商业可交付)</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 rounded-xl border border-amber-200 bg-amber-50/50">
                        <RefreshCcw className="w-5 h-5 text-amber-600 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-semibold text-amber-800">70-84分 · 待修</p>
                          <p className="text-xs text-gray-500">必须先补修复包后再生成</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 rounded-xl border border-red-200 bg-red-50/50">
                        <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-semibold text-red-800">&lt; 70分 · 拒绝</p>
                          <p className="text-xs text-gray-500">禁止进入生成，先重构</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <span className="font-medium text-gray-700">等级锚点:</span>
                    <Badge variant="outline" className="border-gray-300 text-gray-600">S (90-100)</Badge>
                    <Badge variant="outline" className="border-gray-300 text-gray-600">A (80-89)</Badge>
                    <Badge variant="outline" className="border-gray-300 text-gray-600">B (70-79)</Badge>
                    <Badge variant="outline" className="border-gray-300 text-gray-600">C (&lt;70)</Badge>
                  </div>

                  <div className="p-3 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                    <span className="text-amber-400">核心命令:</span> node scr***/cor****.js evaluate --type type2|type3 --input inp****.json --output res****.json
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 3: 五重一票否决机制 ---- */}
            <motion.div variants={fadeInUp} custom={2}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                      <Shield className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">03</span>
                        <CardTitle className="text-xl font-bold text-gray-900">五重一票否决机制</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    命中任意一项即直接驳回，不进入生成阶段。这是质量把控的最后一道防线。5个闭环检查维度：
                  </p>
                  <div className="space-y-3">
                    {[
                      { title: '时序闭环', desc: '分段时长总和=集内时长，时间码无重叠/倒序/断档，镜号顺序连续可追踪' },
                      { title: '连续性闭环', desc: '主角色外观描述全程一致，关键服装/道具连续镜头中一致，场景光色与空间逻辑一致' },
                      { title: '执行闭环', desc: '平台参数完整(分辨率/帧率/比例/时长)，negative prompt存在且可用，素材清单文件名与prompt引用一一对应' },
                      { title: '交付闭环', desc: '每个partXX可脱离聊天独立执行，有参考版与无参考兜底版都存在，返工口径明确' },
                      { title: '合规闭环', desc: '平台违规风险已排除，版权与肖像风险已确认' },
                    ].map((item) => (
                      <div key={item.title} className="flex items-start gap-3 p-3 rounded-xl bg-red-50/40 border border-red-100">
                        <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-gray-900 text-sm">{item.title}</p>
                          <p className="text-sm text-gray-600 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                    <span className="text-amber-400">核心命令:</span> node scr***/cor****.js veto --input vet****.json --output vet**********.json
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 4: 标准交付模板体系 ---- */}
            <motion.div variants={fadeInUp} custom={3}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                      <FileCheck className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">04</span>
                        <CardTitle className="text-xl font-bold text-gray-900">标准交付模板体系</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    评估通过后，系统按照严格的标准化结构输出交付物。每个交付包必须包含完整的四层文件结构：
                  </p>
                  <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 font-mono text-xs leading-relaxed text-gray-700 overflow-x-auto">
                    <pre className="whitespace-pre">{`E0X/                           ← 单集目录
├─ 01_AI短剧****.md              ← 场景级执行指引
├─ 02_专业制****.md              ← 专业制作团队参考
├─ 03_分镜执****.md              ← 分镜团队执行稿
└─ 04_AI生成****/                ← AI生成团队核心工作目录
   ├─ 00_本集生****.md            ← 本集全局说明
   ├─ 01_本集总****.md            ← 全集时序一览
   ├─ 02_本集连****.md            ← 角色锚点/场景底线/道具锁定
   ├─ part01/                     ← 第一段(6件套)
   │  ├─ 01_时序分****.md          ← 时间码+镜号+内容
   │  ├─ 02_素材清****.md          ← 所需素材文件列表
   │  ├─ 03_See****.md            ← 豆包视频一键复制
   │  ├─ 04_Gem****.md            ← Gemini一键复制
   │  ├─ 05_连续性****.md          ← 漂移检查清单
   │  └─ 06_转发执****.md          ← 可直接转发的执行说明
   ├─ part02/ (同结构)
   └─ part03/ (同结构)`}</pre>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100">
                      <p className="font-semibold text-gray-900 text-sm mb-1">防呆设计</p>
                      <p className="text-xs text-gray-600 leading-relaxed">
                        每个partXX必须独立可执行，不依赖聊天解释。每个平台稿必须给&ldquo;双版本&rdquo;：有参考素材版+无参考兜底版。所有返工指令只允许改三项：错误时间码、漂移元素、重跑范围。
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100">
                      <p className="font-semibold text-gray-900 text-sm mb-1">交付返工口径</p>
                      <p className="text-xs text-gray-600 leading-relaxed">
                        1) 错误时间码 &nbsp; 2) 漂移元素(角色/道具/场景) &nbsp; 3) 重跑范围(整段/补镜)
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 5: 甲方驳回诊断系统 ---- */}
            <motion.div variants={fadeInUp} custom={4}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                      <Search className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">05</span>
                        <CardTitle className="text-xl font-bold text-gray-900">甲方驳回诊断系统</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    当客户说&ldquo;被打回了&rdquo;&ldquo;甲方不满意&rdquo;，系统提供专业的驳回诊断流程。不是猜测原因，而是对照商业原因图谱进行系统性定位。
                  </p>

                  <div className="rounded-xl border border-gray-200 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="font-semibold text-gray-900">一级原因</TableHead>
                          <TableHead className="font-semibold text-gray-900">二级根因</TableHead>
                          <TableHead className="font-semibold text-gray-900">典型信号</TableHead>
                          <TableHead className="font-semibold text-gray-900">商业影响</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rejectionCauses.map((row) => (
                          <TableRow key={row.cause}>
                            <TableCell className="font-medium text-gray-900">{row.cause}</TableCell>
                            <TableCell className="text-gray-600 text-sm">{row.root}</TableCell>
                            <TableCell className="text-gray-600 text-sm">{row.signal}</TableCell>
                            <TableCell className="text-gray-600 text-sm">{row.impact}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="p-3 rounded-xl bg-orange-50/60 border border-orange-100">
                    <p className="font-semibold text-gray-900 text-sm mb-1">诊断输出闭环</p>
                    <p className="text-xs text-gray-600 leading-relaxed">
                      根因(1-3个) → 证据(文件或反馈原句) → 商业影响 → 修复动作(可执行) → 复评标准(可量化)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 6: 客户端问题诊断 ---- */}
            <motion.div variants={fadeInUp} custom={5}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-gray-100 border border-gray-200">
                      <Wrench className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">06</span>
                        <CardTitle className="text-xl font-bold text-gray-900">客户端问题诊断</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    解决终端用户在实际使用中的环境问题。包括文档打不开、编码乱码、格式不兼容等。
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { title: 'DOCX打不开', desc: '转ZIP检查wor****/doc*****.xml / 要求导出Markdown / 提取纯文本' },
                      { title: '文件乱码', desc: '探测编码(UTF-8/GBK/UTF-16) → 统一转UTF-8 → 抽样校验' },
                      { title: '大文件处理', desc: '按结构切块(章/节/标题) → 逐块摘要 → 合并总摘要 → 关键引用索引' },
                      { title: '导出需求', desc: 'ZIP打包(含README) / Markdown结构化输出' },
                    ].map((item) => (
                      <div key={item.title} className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                        <p className="font-semibold text-gray-900 text-sm">{item.title}</p>
                        <p className="text-xs text-gray-600 leading-relaxed mt-1">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <p className="font-semibold text-gray-900 text-sm">常用命令</p>
                    <div className="p-2.5 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                      <span className="text-amber-400">编码修复:</span> python scr***/fix****.py --input &lt;file&gt; --output &lt;utf8file&gt;
                    </div>
                    <div className="p-2.5 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                      <span className="text-amber-400">大文件摘要:</span> python scr***/chu****.py --input &lt;file&gt; --output &lt;sum****.md&gt;
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 7: 跨平台兼容与一键发布 ---- */}
            <motion.div variants={fadeInUp} custom={6}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                      <Globe className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">07</span>
                        <CardTitle className="text-xl font-bold text-gray-900">跨平台兼容与一键发布</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    一次编写，五个平台通用。工具箱内置自动化转换系统，可将技能包一键转换为目标AI平台的初始化格式。
                  </p>
                  <div className="rounded-xl border border-gray-200 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="font-semibold text-gray-900">平台</TableHead>
                          <TableHead className="font-semibold text-gray-900">主入口文件</TableHead>
                          <TableHead className="font-semibold text-gray-900">兼容要点</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {platforms.map((row) => (
                          <TableRow key={row.name}>
                            <TableCell className="font-medium text-gray-900">{row.name}</TableCell>
                            <TableCell className="text-gray-600 text-sm font-mono">{row.entry}</TableCell>
                            <TableCell className="text-gray-600 text-sm">{row.compat}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="p-3 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto">
                    <span className="text-amber-400">一键命令:</span> python scr***/bui****.py --source . --name &quot;XIA&apos;S-AI短剧制作工具箱V1&quot;
                  </div>
                  <p className="text-xs text-gray-500">自动完成：多平台转换 + UTF-8守护 + 单一通用离线包输出</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 8: 安全与输出闸门 ---- */}
            <motion.div variants={fadeInUp} custom={7}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-violet-50 border border-violet-200">
                      <Lock className="w-5 h-5 text-violet-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">08</span>
                        <CardTitle className="text-xl font-bold text-gray-900">安全与输出闸门</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    内置输出安全过滤机制，防止在交付给客户时泄露内部规则、工具路径或技术实现细节。
                  </p>
                  <div className="p-3 rounded-xl bg-violet-50/60 border border-violet-100">
                    <p className="font-semibold text-gray-900 text-sm mb-2">防泄露模式</p>
                    <div className="p-2.5 rounded-lg bg-gray-900 text-gray-100 font-mono text-xs overflow-x-auto mb-2">
                      node scr***/cor****.js sanitize --input draft.txt --output safe.txt --strict
                    </div>
                    <p className="text-xs text-gray-600">
                      <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800">--strict</code> 模式命中泄露模式直接阻断输出。
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm mb-2">过滤内容</p>
                    <div className="flex flex-wrap gap-2">
                      {['工具调用块', '内部路径', '思考过程标记', '调试信息', '开发注释'].map((item) => (
                        <Badge key={item} variant="outline" className="border-gray-200 text-gray-600 text-xs">{item}</Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 9: 环境兼容策略 ---- */}
            <motion.div variants={fadeInUp} custom={8}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                      <Server className="w-5 h-5 text-teal-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">09</span>
                        <CardTitle className="text-xl font-bold text-gray-900">环境兼容策略</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    针对不同部署环境提供三档安装策略，确保&ldquo;安装失败不等于流程失败&rdquo;。
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-100 text-center">
                      <p className="font-bold text-emerald-800 text-lg mb-1">A档</p>
                      <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-2">在线环境</p>
                      <p className="text-xs text-gray-600">标准依赖安装，完整解析链路</p>
                    </div>
                    <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-100 text-center">
                      <p className="font-bold text-amber-800 text-lg mb-1">B档</p>
                      <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-2">受限网络</p>
                      <p className="text-xs text-gray-600">使用镜像源/预打包依赖，优先本地解析</p>
                    </div>
                    <div className="p-4 rounded-xl bg-red-50/60 border border-red-100 text-center">
                      <p className="font-bold text-red-800 text-lg mb-1">C档</p>
                      <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-2">离线环境</p>
                      <p className="text-xs text-gray-600">预置轮子/离线包，不依赖远程API，最小能力保底</p>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">
                    C档最小保底能力：UTF-8文本读取 + ZIP处理 + 大文件分块
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 10: 专业术语自查体系 ---- */}
            <motion.div variants={fadeInUp} custom={9}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200">
                      <BookOpen className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">10</span>
                        <CardTitle className="text-xl font-bold text-gray-900">专业术语自查体系</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    杜绝&ldquo;画面要高级&rdquo;&ldquo;节奏要紧张&rdquo;这类不可验收表达。所有输出必须符合&ldquo;术语+白话动作+结果目标&rdquo;标准。
                  </p>
                  <div className="rounded-xl border border-gray-200 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="font-semibold text-gray-900">高风险说法</TableHead>
                          <TableHead className="font-semibold text-gray-900">专业替换</TableHead>
                          <TableHead className="font-semibold text-gray-900">验收方式</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {terminologyReplacements.map((row) => (
                          <TableRow key={row.risky}>
                            <TableCell className="text-red-600 text-sm font-medium">{row.risky}</TableCell>
                            <TableCell className="text-gray-700 text-sm">{row.pro}</TableCell>
                            <TableCell className="text-emerald-600 text-sm">{row.check}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="p-3 rounded-xl bg-yellow-50/60 border border-yellow-100">
                    <p className="font-semibold text-gray-900 text-sm mb-1">Prompt语句自查清单</p>
                    <div className="flex flex-wrap gap-2">
                      {['景别明确', '动作可观察', '环境可描述', 'negative完整', '参数齐全'].map((item) => (
                        <Badge key={item} className="bg-yellow-100 text-yellow-800 border-yellow-200 text-xs">{item}</Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 11: 上线验收标准 ---- */}
            <motion.div variants={fadeInUp} custom={10}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">11</span>
                        <CardTitle className="text-xl font-bold text-gray-900">上线验收标准</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    商业交付前的最后一道关卡，确保交付物达到可发布标准。5个验收维度：
                  </p>
                  <div className="space-y-3">
                    {[
                      { code: 'A', title: '可执行性', desc: '小白首轮成功 / 无需额外解释 / partXX独立可执行', color: 'bg-blue-50 border-blue-100' },
                      { code: 'B', title: '稳定性', desc: '分段通过率≥85% / 返工≤2轮 / 致命错误≤1个/集', color: 'bg-amber-50 border-amber-100' },
                      { code: 'C', title: '完整性', desc: 'E0X结构完整 / 六件套齐全 / 参数映射齐全', color: 'bg-violet-50 border-violet-100' },
                      { code: 'D', title: '合规性', desc: '版权/肖像/平台违规已确认', color: 'bg-red-50 border-red-100' },
                      { code: 'E', title: '结果判定', desc: '允许上线 / 不允许上线(必须写原因)', color: 'bg-emerald-50 border-emerald-100' },
                    ].map((item) => (
                      <div key={item.code} className={`flex items-start gap-3 p-3 rounded-xl border ${item.color}`}>
                        <span className="flex-shrink-0 w-7 h-7 rounded-full bg-white shadow-sm flex items-center justify-center text-xs font-bold text-gray-700">
                          {item.code}
                        </span>
                        <div>
                          <p className="font-semibold text-gray-900 text-sm">{item.title}</p>
                          <p className="text-xs text-gray-600 leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* ---- Card 12: 触发词与渐进式导航 ---- */}
            <motion.div variants={fadeInUp} custom={11}>
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                      <Zap className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">12</span>
                        <CardTitle className="text-xl font-bold text-gray-900">触发词与渐进式导航</CardTitle>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  <p className="text-gray-600 leading-relaxed">
                    内置智能触发词系统，用户说出特定关键词即可自动激活对应工作模式，无需记忆复杂指令。同时采用渐进式信息披露，防止信息过载。
                  </p>

                  {/* Trigger Keywords */}
                  <div>
                    <p className="font-semibold text-gray-900 mb-3">5类触发关键词</p>
                    <div className="space-y-3">
                      {[
                        { cat: '评估模式', kws: ['"评估一下"', '"帮我看看"', '"能不能用"', '"评分"', '"打分"'] },
                        { cat: '驳回诊断', kws: ['"被打回"', '"甲方不满意"', '"驳回了"', '"退回来了"'] },
                        { cat: '问题诊断', kws: ['"打不开"', '"乱码"', '"报错"', '"不兼容"'] },
                        { cat: '类型2路由', kws: ['"从零开始"', '"只有想法"', '"我想创作"', '"帮我写"'] },
                        { cat: '类型3路由', kws: ['"我有剧本"', '"帮我拆分镜"', '"按这个文本做"'] },
                      ].map((group) => (
                        <div key={group.cat} className="flex items-start gap-3">
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 flex-shrink-0 mt-0.5">{group.cat}</Badge>
                          <div className="flex flex-wrap gap-1.5">
                            {group.kws.map((kw) => (
                              <span key={kw} className="px-2 py-0.5 rounded bg-gray-100 text-gray-700 text-xs">{kw}</span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Progressive Disclosure */}
                  <div>
                    <p className="font-semibold text-gray-900 mb-3">渐进式披露4层</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { layer: '第1层', label: '必看', desc: 'SKI****.md 总规则+路由判型' },
                        { layer: '第2层', label: '按需', desc: '评分模板+一票否决清单' },
                        { layer: '第3层', label: '修复时', desc: '修复工单+驳回诊断' },
                        { layer: '第4层', label: '上线前', desc: '验收清单+术语自查' },
                      ].map((item) => (
                        <div key={item.layer} className="flex items-start gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100">
                          <span className="flex-shrink-0 px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-xs font-bold">{item.layer}</span>
                          <div>
                            <Badge variant="outline" className="border-gray-200 text-gray-600 text-[10px] mb-1">{item.label}</Badge>
                            <p className="text-xs text-gray-600">{item.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 2.5: XHS MARKETING STRATEGY
          ============================================================ */}
      <section id="xhs-marketing" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <motion.div
            className="text-center mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Badge className="mb-4 bg-rose-600 text-white border-rose-600 px-3 py-1 text-sm">
              <Megaphone className="w-3.5 h-3.5 mr-1.5" />
              小红书营销
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">小红书营销策略顾问</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              基于 OPC 架构的 AI 自主运营系统 — 从账号冷启动到成熟变现的全栈策略
            </p>
          </motion.div>

          {/* Stats Bar */}
          <motion.div
            className="grid grid-cols-2 sm:grid-cols-5 gap-3 max-w-4xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {xhsStats.map((stat, i) => (
              <motion.div key={stat.label} variants={fadeInUp} custom={i}>
                <div className="text-center p-3 rounded-2xl border border-rose-100 bg-rose-50/50 shadow-sm">
                  <p className="text-xl font-bold text-rose-600">{stat.value}</p>
                  <p className="text-[10px] text-gray-500 mt-0.5 uppercase tracking-wider font-medium">
                    {stat.label}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* OPC Architecture */}
          <motion.div
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">OPC 四层架构</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {xhsArchitecture.map((item) => (
                <Card key={item.layer} className={`border ${item.color} shadow-sm rounded-2xl`}>
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`p-2 rounded-lg ${item.color}`}>
                        <item.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900">{item.layer}</p>
                        <p className="text-xs text-gray-500">{item.label}</p>
                      </div>
                    </div>
                    <p className="text-xs text-gray-600 leading-relaxed">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>

          {/* 6-Step Workflow */}
          <motion.div
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">6步工作流程</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {xhsWorkflow.map((item, i) => (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                >
                  <div className="flex items-start gap-3 p-4 rounded-xl border border-gray-200 bg-white shadow-sm hover:border-rose-200 hover:shadow-md transition-all">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-rose-600 flex items-center justify-center text-sm font-bold text-white">
                      {item.step}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 text-sm mb-1">{item.title}</p>
                      <p className="text-xs text-gray-600 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Core Capabilities - 6 Cards Grid */}
          <motion.div
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">核心能力矩阵</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

              {/* Card 1: CES Algorithm */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200">
                      <BarChart3 className="w-5 h-5 text-rose-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">算法理解 — CES 评分机制</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <div className="rounded-xl border border-gray-200 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="font-semibold text-gray-900 text-sm">互动行为</TableHead>
                          <TableHead className="font-semibold text-gray-900 text-sm text-center">权重</TableHead>
                          <TableHead className="font-semibold text-gray-900 text-sm">说明</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {xhsCesData.map((row) => (
                          <TableRow key={row.action}>
                            <TableCell className="font-medium text-gray-900 text-sm">{row.action}</TableCell>
                            <TableCell className="text-center">
                              <Badge className="bg-rose-50 text-rose-700 border-rose-200">{row.weight}</Badge>
                            </TableCell>
                            <TableCell className="text-gray-600 text-xs">{row.note}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-xs mb-2">流量池晋升路径</p>
                    <div className="flex flex-wrap gap-2">
                      {xhsTrafficPool.map((item) => (
                        <div key={item.level} className="px-3 py-1.5 rounded-lg bg-gray-50 border border-gray-100 text-xs">
                          <span className="font-semibold text-gray-900">{item.level}</span>
                          <span className="text-gray-400 mx-1">({item.range})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Card 2: Content Strategy */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                      <FileText className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">内容策略 — 5大规则</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <div className="space-y-2">
                    {xhsContentRules.map((item) => (
                      <div key={item.rule} className="flex items-start gap-2">
                        <Badge className={`text-[10px] px-1.5 py-0 flex-shrink-0 mt-0.5 ${getPriorityBadge(item.priority)}`}>{item.priority}</Badge>
                        <p className="text-sm text-gray-700">{item.rule}</p>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 rounded-xl bg-orange-50/60 border border-orange-100">
                    <p className="font-semibold text-gray-900 text-xs mb-2">6大标题公式</p>
                    <div className="flex flex-wrap gap-1.5">
                      {xhsTitleFormulas.map((f) => (
                        <Badge key={f} variant="outline" className="border-orange-200 text-orange-700 text-[10px]">{f}</Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Card 3: Interaction Operations */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-pink-50 border border-pink-200">
                      <MessageSquare className="w-5 h-5 text-pink-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">互动运营 — 3大规则</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  {xhsInteractionRules.map((item) => (
                    <div key={item.rule} className="flex items-start gap-2 p-3 rounded-xl bg-pink-50/40 border border-pink-100">
                      <Badge className={`text-[10px] px-1.5 py-0 flex-shrink-0 mt-0.5 ${getPriorityBadge(item.priority)}`}>{item.priority}</Badge>
                      <p className="text-sm text-gray-700">{item.rule}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Card 4: Growth Strategy */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                      <TrendingUp className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">增长策略 — 4大规则</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  {xhsGrowthRules.map((item) => (
                    <div key={item.rule} className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50/40 border border-emerald-100">
                      <Badge className={`text-[10px] px-1.5 py-0 flex-shrink-0 mt-0.5 ${getPriorityBadge(item.priority)}`}>{item.priority}</Badge>
                      <p className="text-sm text-gray-700">{item.rule}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Card 5: Monetization Map */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                      <Wallet className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">变现路径 — 全景地图</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <div className="rounded-xl border border-gray-200 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="font-semibold text-gray-900 text-sm">粉丝量</TableHead>
                          <TableHead className="font-semibold text-gray-900 text-sm">主要变现方式</TableHead>
                          <TableHead className="font-semibold text-gray-900 text-sm text-center">月收入预期</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {xhsMonetization.map((row) => (
                          <TableRow key={row.fans}>
                            <TableCell className="font-medium text-gray-900 text-sm">{row.fans}</TableCell>
                            <TableCell className="text-gray-600 text-xs">{row.method}</TableCell>
                            <TableCell className="text-center">
                              <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-xs">{row.income}</Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-xs mb-2">品牌合作报价参考</p>
                    <div className="flex flex-wrap gap-2">
                      {xhsBrandPricing.map((item) => (
                        <div key={item.type} className="px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-100 text-xs">
                          <span className="font-semibold text-amber-800">{item.type}</span>
                          <span className="text-gray-500 mx-1">{item.formula}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Card 6: HEARTBEAT Scheduling */}
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-violet-50 border border-violet-200">
                      <Timer className="w-5 h-5 text-violet-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-bold text-gray-900">自主调度系统 (HEARTBEAT)</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-3">
                  {xhsHeartbeatSchedule.map((item) => (
                    <div key={item.time} className="flex items-start gap-3 p-3 rounded-xl bg-violet-50/40 border border-violet-100">
                      <Clock className="w-4 h-4 text-violet-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-gray-900 text-xs">{item.time}</p>
                        <p className="text-xs text-gray-600">{item.tasks}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </motion.div>

          {/* Templates, Knowledge Base & External Tools */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Templates */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl h-full">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-rose-500" />
                    <CardTitle className="text-base font-bold text-gray-900">可复用模板 (6个)</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-3">
                  <div className="space-y-2">
                    {xhsTemplates.map((t) => (
                      <div key={t.name} className="flex items-start gap-2">
                        <span className="text-xs font-mono text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded flex-shrink-0">{t.name}</span>
                        <p className="text-xs text-gray-600">{t.desc}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Knowledge Base */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl h-full">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-blue-500" />
                    <CardTitle className="text-base font-bold text-gray-900">知识库文档 (8个)</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-3">
                  <div className="space-y-2">
                    {xhsKnowledgeBase.map((t) => (
                      <div key={t.name} className="flex items-start gap-2">
                        <span className="text-xs font-mono text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded flex-shrink-0">{t.name}</span>
                        <p className="text-xs text-gray-600">{t.desc}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* External Tools */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="border-gray-200 bg-white shadow-sm rounded-2xl h-full">
                <CardHeader className="pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-500" />
                    <CardTitle className="text-base font-bold text-gray-900">外部工具集成</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-3">
                  <div className="space-y-3">
                    {xhsExternalTools.map((tool) => (
                      <div key={tool.name} className="p-2.5 rounded-xl bg-gray-50 border border-gray-100">
                        <p className="font-semibold text-gray-900 text-sm mb-1">{tool.name}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {tool.features.map((f) => (
                            <Badge key={f} variant="outline" className="border-gray-200 text-gray-600 text-[10px]">{f}</Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 3: WORKFLOW DIAGRAM
          ============================================================ */}
      <section id="workflow" className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">完整工作流程图</h2>
            <p className="text-gray-600 text-lg">
              从用户输入到标准交付的全链路流程
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
              <CardContent className="p-4 sm:p-8">
                <MermaidDiagram chart={workflowChart} className="py-2" />
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 4: SCRIPT TOOLS TABLE
          ============================================================ */}
      <section className="py-20 bg-gray-50/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">脚本工具链</h2>
            <p className="text-gray-600 text-lg">
              10个自动化脚本，覆盖路由、评分、否决、编码修复、多平台发布等全流程
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="font-semibold text-gray-900">脚本</TableHead>
                        <TableHead className="font-semibold text-gray-900">语言</TableHead>
                        <TableHead className="font-semibold text-gray-900">功能</TableHead>
                        <TableHead className="font-semibold text-gray-900">命令示例</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {scriptTools.map((tool) => (
                        <TableRow key={tool.name}>
                          <TableCell className="font-mono text-sm font-medium text-gray-900">{tool.name}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                tool.lang === 'Node.js'
                                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                                  : tool.lang === 'Python'
                                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                                  : 'bg-gray-100 text-gray-600 border-gray-200'
                              }
                            >
                              {tool.lang}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-600 text-sm">{tool.func}</TableCell>
                          <TableCell className="font-mono text-xs text-gray-500 max-w-xs">{tool.cmd}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 5: FILE ARCHITECTURE
          ============================================================ */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">文件架构总览</h2>
            <p className="text-gray-600 text-lg">
              完整工具箱包含26个内置文件，覆盖规则、参考、模板、脚本和资源
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="border-gray-200 bg-white shadow-sm rounded-2xl overflow-hidden">
              <CardContent className="p-4 sm:p-8">
                <div className="font-mono text-xs sm:text-sm leading-relaxed text-gray-700 overflow-x-auto">
                  <pre className="whitespace-pre">{fileTreeLines.join('\n')}</pre>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 6: STARTUP SKILLS
          ============================================================ */}
      <section id="startup-skills" className="py-20 bg-gray-50/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Badge className="mb-4 bg-amber-600 text-white border-amber-600 px-3 py-1 text-sm">
              <Zap className="w-3.5 h-3.5 mr-1.5" />
              配套技能
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">创业技能工具箱</h2>
            <p className="text-gray-600 text-lg">
              {totalSkills} 个开箱即用的 AI Agent 技能，覆盖创业全生命周期
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <Accordion type="multiple" className="space-y-3">
              {skillCategories.map((category) => (
                <AccordionItem
                  key={category.name}
                  value={category.name}
                  className="border-gray-200 bg-white rounded-2xl px-4 data-[state=open]:shadow-sm transition-shadow"
                >
                  <AccordionTrigger className="hover:no-underline py-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-gray-50">
                        <category.icon className={`w-4 h-4 ${category.color}`} />
                      </div>
                      <div className="text-left">
                        <span className="text-sm font-semibold text-gray-900">{category.name}</span>
                        <span className="text-xs text-gray-400 ml-2">{category.skills.length} 个技能</span>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pb-2">
                      {category.skills.map((skill) => (
                        <Card
                          key={skill.name}
                          className="border-gray-100 bg-gray-50/50 hover:border-gray-200 hover:bg-gray-50 transition-all duration-200 group"
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 min-w-0">
                                <Terminal className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                                <span className="text-sm font-medium text-gray-900 truncate group-hover:text-amber-600 transition-colors">
                                  {skill.name}
                                </span>
                              </div>
                              <Badge
                                variant="outline"
                                className={`text-[10px] px-1.5 py-0 flex-shrink-0 ${getConfidenceColor(skill.confidence)}`}
                              >
                                {skill.confidence}%
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">
                              {skill.description}
                            </p>
                            <div className="mt-2 flex items-center gap-1.5 text-[10px] text-gray-400">
                              <span className="opacity-60">@</span>
                              <span>{skill.author}</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 7: ACTIVATION GUIDE
          ============================================================ */}
      <section id="activation" className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">激活指南</h2>
            <p className="text-gray-600 text-lg">
              5步快速激活工具箱，开始AI短剧创作
            </p>
          </motion.div>

          <motion.div
            className="max-w-3xl mx-auto space-y-4"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {activationSteps.map((item, i) => (
              <motion.div key={item.step} variants={fadeInUp} custom={i}>
                <div className="flex items-start gap-4 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm hover:border-amber-200 transition-colors">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-amber-600 flex items-center justify-center text-sm font-bold text-white">
                    {item.step}
                  </div>
                  <div className="flex-1 min-w-0">
                    {item.mono ? (
                      <>
                        <p className="text-sm text-gray-700 mb-2">{item.text}</p>
                        <code className="block text-xs text-amber-700 bg-amber-50 border border-amber-100 px-3 py-2 rounded-lg overflow-x-auto whitespace-pre-wrap break-all">
                          {item.mono}
                        </code>
                      </>
                    ) : (
                      <p className="text-sm text-gray-700 leading-relaxed pt-1">{item.text}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <Separator className="bg-gray-200" />

      {/* ============================================================
          SECTION 8: FOOTER
          ============================================================ */}
      <footer className="py-10 bg-gray-50/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span className="font-bold text-gray-900">XIA&apos;S-AI 短剧制作工具箱 V1</span>
            </div>
            <p className="text-sm text-gray-500">闭源商业技能包 · 保留所有权利</p>
            <Separator className="max-w-xs mx-auto bg-gray-200" />
            <div className="flex items-center justify-center gap-1.5 text-sm text-gray-400">
              <span>Powered by</span>
              <span className="font-semibold text-gray-600">Z.ai</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
