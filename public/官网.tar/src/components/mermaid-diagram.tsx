'use client'

import { useEffect, useRef, useId } from 'react'
import mermaid from 'mermaid'

mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  themeVariables: {
    primaryColor: '#fef3c7',
    primaryTextColor: '#1f2937',
    primaryBorderColor: '#d97706',
    lineColor: '#f59e0b',
    secondaryColor: '#f3f4f6',
    tertiaryColor: '#ffffff',
    fontSize: '14px',
  },
  flowchart: {
    htmlLabels: true,
    curve: 'basis',
    useMaxWidth: true,
  },
})

interface MermaidDiagramProps {
  chart: string
  className?: string
}

export function MermaidDiagram({ chart, className }: MermaidDiagramProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const uniqueId = useId().replace(/:/g, '-')

  useEffect(() => {
    if (containerRef.current) {
      const render = async () => {
        try {
          const { svg } = await mermaid.render(`mermaid-${uniqueId}`, chart)
          if (containerRef.current) {
            containerRef.current.innerHTML = svg
          }
        } catch (error) {
          console.error('Mermaid render error:', error)
        }
      }
      render()
    }
  }, [chart, uniqueId])

  return (
    <div
      ref={containerRef}
      className={`flex justify-center overflow-x-auto [&>svg]:max-w-full [&>svg]:w-auto ${className || ''}`}
    />
  )
}
